def hello():
    print('hello')

import tkinter as tk
from tkinter import *
from tkinter import ttk, messagebox
import mysql.connector

roothaha = tk.Tk()

canvas = tk.Canvas(roothaha, height=600, width=1067, bg='#52ECDC')
canvas.pack()

bg_image = tk.PhotoImage(file='hands typing600.png')
bg_label = tk.Label(roothaha, image=bg_image)
bg_label.place(relwidth=1, relheight=1)
frame1 = tk.Frame(roothaha, bg='brown')
frame1.place(relx=0.5, rely=0.2, relwidth=0.7, relheight=0.1, anchor='n')

label = tk.Label(frame1, text='User Name:', bg='yellow', font=40)
label.place(relx=0, relheight=1, relwidth=0.2)

entry_email = tk.Entry(frame1, bd=4, font=80)
entry_email.place(relx=0.2, relheight=1, relwidth=0.8)
def getusername():
    entry_email.get()

frame2 = tk.Frame(roothaha, bg='red')
frame2.place(relx=0.5, rely=0.4, relwidth=0.7, relheight=0.1, anchor='n')

label = tk.Label(frame2, text='Password:', bg='yellow', font=40)
label.place(relx=0, relheight=1, relwidth=0.2)

entry_passwd = tk.Entry(frame2, bd=4, show='*', font=80)
entry_passwd.place(relx=0.2, relheight=1, relwidth=0.8)

entry_passwd.delete(0, 'end')

def Login():
    db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
    cursor = db.cursor()
    cursor.execute('select username,password,status from userw inner join status on userw.username=status.user',(

    ))
    res = cursor.fetchall()

    cursor.execute('select username from userw', (

    ))
    resusername = cursor.fetchall()
    cursor.execute('select password from userw', (

    ))


    respassword = cursor.fetchall()
    usernamelist=[]
    for x in resusername:
        for y in x:
            usernamelist.append(y)

    passwordlist = []
    for w in respassword:
        for k in w:
            passwordlist.append(k)

    #print(entry_passwd.get() in passwordlist)

    i=0


    while (i < len(res)):




        if entry_email.get()=='' and entry_passwd.get()=='':
            tk.messagebox.showerror(" ERROR", "PLEASE INSERT A USERNAME AND A VALID PASSWORD")
            break

        elif entry_email.get()=='' and entry_passwd.get():
            tk.messagebox.showerror("USERNAME ERROR","PLEASE INSERT A USERNAME")
            entry_email.delete(0, END)
            entry_passwd.delete(0, END)
            break
        elif entry_passwd.get()=='' and entry_email.get():
            tk.messagebox.showerror("PASSWORD ERROR", "PLEASE INSERT A PASSWORD")
            entry_email.delete(0, END)
            entry_passwd.delete(0, END)
            break


        elif res[i][0]==entry_email.get() and res[i][1]==entry_passwd.get() and res[i][2]=={'MANAGER'}:
            managerpage()
            break


    db.commit()
    db.close()




button = tk.Button(roothaha, text='LOGIN', fg='red', command=Login, font=80, )
button.place(relx=0.5, rely=0.55, relheight=0.1, relwidth=0.2, anchor='n')

roothaha.mainloop()



def managerpage():
    management= tk.Tk()
    management.title('MANAGER ACCOUNT')
    canvas = tk.Canvas(management, bg='red', height=600, width=1067)
    canvas.pack()
    label = tk.Label(management, text='MANAGER ACCOUNT',fg='red', font=100)
    label.place(relx=0.42, rely=0.1)

    comp_button = tk.Button(management, text='COMPANY INFO', fg='red', command=company)
    comp_button.place(relx=0.1, rely=0.35 ,relwidth=0.2, relheight=0.1)
    def delete_management(ev):
        management.destroy()
    personal_button = tk.Button(management, text='PERSONAL INFO', fg='red', command=personal, )
    personal_button.place(relx=0.4, rely=0.35 ,relwidth=0.2, relheight=0.1)





    employee_button = tk.Button(management, text='EMPLOYEE INFO', fg='red', command=Employee)
    employee_button.place(relx=0.7, rely=0.35, relwidth=0.2, relheight=0.1)

    evaluation_button = tk.Button(management, text='JOB SALARY/EVALUATION', fg='red', command=Job)
    evaluation_button.place(relx=0.4, rely=0.6 ,relwidth=0.2, relheight=0.1)

    searchbutt = tk.Button(management, text='SEARCH FOR AN EMPLOYEE', fg='red', command=Searchgui)
    searchbutt.place(relx=0.1, rely=0.6 ,relwidth=0.2, relheight=0.1)


    management.mainloop()
    # ---------------COMPANY----------------
def company():

    company1=tk.Toplevel()

    company1.title('COMPANY INFORMATION')
    canvas = tk.Canvas(company1, bg='red', height=600, width=1067)
    canvas.pack()
    frame1 = tk.Frame(company1, bg='white')
    frame1.place(relx=0.5, rely=0, relwidth=0.4, relheight=0.7, anchor='n')
    #label = tk.Label(company1, text='COMPANY INFO', fg='red', font=100)
    #label.place(relx=0.42, rely=0.1)
    bottomframe = tk.Frame(company1, bg='white')
    bottomframe.place(relx=0,rely=0.71, relwidth=0.8, relheight=0.3)
    rightframe = tk.Frame(company1, bg='yellow')
    rightframe.place(relx=0.82, rely=0.2, relwidth=0.15, relheight=0.4)




    # ------ VARIABLE DECLARATION---------
    afm1 = StringVar()
    DOY = tk.StringVar()
    NAME = tk.StringVar()
    PHONE = tk.StringVar()
    STREET = tk.StringVar()
    NUM = tk.StringVar()
    CITY = tk.StringVar()
    COUNTRY = tk.StringVar()
    # ----------------------LABELS AND ENTRIES FOR COMPANY---------------------------------





    afm = tk.Label(frame1, text='AFM', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=0, column=0, sticky='W', padx=5)
    afmentry = tk.Entry(frame1, textvariable=afm1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    afmentry.grid(row=0, column=1, sticky='W', padx=5)


    doy = tk.Label(frame1, text='DOY', fg='red', font=('arial', 12, 'bold'), bd=7)
    doy.grid(row=1, column=0, sticky='W', padx=5)
    doyentry = tk.Entry(frame1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable='DOY')
    doyentry.grid(row=1, column=1, sticky='W', padx=5)

    name = tk.Label(frame1, text='NAME', fg='red', font=('arial', 12, 'bold'), bd=7)
    name.grid(row=2, column=0, sticky='W', padx=5)
    nameentry = tk.Entry(frame1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=NAME)
    nameentry.grid(row=2, column=1, sticky='W', padx=5)

    phone = tk.Label(frame1, text='PHONE', fg='red',font=('arial', 12,'bold'), bd=7)
    phone.grid(row= 3, column=0, sticky='W', padx=5)
    phoneentry = tk.Entry(frame1, width=44,font=('arial', 12,'bold'), bd=5, justify='left', textvariable=PHONE)
    phoneentry.grid(row=3, column=1, sticky='W', padx=5)

    street = tk.Label(frame1, text='STREET', fg='red', font=('arial', 12, 'bold'), bd=7)
    street.grid(row=4, column=0, sticky='W', padx=5)
    streetentry = tk.Entry(frame1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=STREET)
    streetentry.grid(row=4, column=1, sticky='W', padx=5)

    num = tk.Label(frame1, text='NUMBER', fg='red', font=('arial', 12, 'bold'), bd=7)
    num.grid(row=5, column=0, sticky='W', padx=5)
    numentry = tk.Entry(frame1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=NUM)
    numentry.grid(row=5, column=1, sticky='W', padx=5)

    phone = tk.Label(frame1, text='CITY', fg='red', font=('arial', 12, 'bold'), bd=7)
    phone.grid(row=6, column=0, sticky='W', padx=5)
    cityentry = tk.Entry(frame1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=CITY)
    cityentry.grid(row=6, column=1, sticky='W', padx=5)

    country = tk.Label(frame1, text='COUNTRY', fg='red', font=('arial', 12, 'bold'), bd=7)
    country.grid(row=7, column=0, sticky='W', padx=5)
    countryentry = tk.Entry(frame1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=COUNTRY)
    countryentry.grid(row=7, column=1, sticky='W', padx=5)

    # -----------CONTENT OF TREEVIEW-------------
    def Traineeinfo(ev):
        viewinfo = records.focus()
        data = records.item(viewinfo)

        row = data['values']

        afmentry.delete(0,END)
        afmentry.insert(END,row[0])
        doyentry.delete(0,END)
        doyentry.insert(END, row[1])
        nameentry.delete(0, END)
        nameentry.insert(END, row[2])
        phoneentry.delete(0, END)
        phoneentry.insert(END, row[3])
        streetentry.delete(0, END)
        streetentry.insert(END, row[4])
        numentry.delete(0, END)
        numentry.insert(END, row[5])
        cityentry.delete(0, END)
        cityentry.insert(END, row[6])
        countryentry.delete(0, END)
        countryentry.insert(END, row[7])


    # ------------------CREATION OF TREEVIEW----------------------------------

    scrollbar = Scrollbar(bottomframe, orient=VERTICAL)
    records = ttk.Treeview(bottomframe, yscrollcommand = scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns']=( 'AFM','DOY', 'NAME', 'PHONE', 'STREET', 'NUM', 'CITY', 'COUNTRY')

    records.column('AFM', width=60)
    records.column('DOY', width=60)
    records.column('NAME', width=60)
    records.column('PHONE', width=60)
    records.column('STREET', width=60)
    records.column('NUM', width=60)
    records.column('CITY', width=60)
    records.column('COUNTRY', width=60)

    records['show'] = 'headings'

    records.heading('AFM', text='AFM')
    records.heading('DOY', text='DOY')
    records.heading('NAME', text='Name')
    records.heading('PHONE', text='Phone')
    records.heading('STREET', text='Street')
    records.heading('NUM', text='Number')
    records.heading('CITY', text='City')
    records.heading('COUNTRY', text='Country')
    records.pack(fill=BOTH)
    records.bind('<Double-1>', Traineeinfo)















    # --------------DISPLAY-UPDATE-EXIT--------------------------
    def Display():

        db = mysql.connector.connect(host='127.0.0.1',  user='root', port=3306, password='123456', database='staff')
        cursor = db.cursor()
        cursor.execute('SELECT * FROM company')
        res = cursor.fetchall()
        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                #print(x)

                records.insert('',END,values = x)
        db.commit()
        db.close()

    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        cursor.execute('update staff.company set phone=%s,street=%s,num=%s,city=%s,country=%s where AFM=%s and DOY=%s and name=%s',(



        phoneentry.get(),
        streetentry.get(),
        numentry.get(),
        cityentry.get(),
        countryentry.get(),
        afmentry.get(),
        doyentry.get(),
        nameentry.get()
        ))

        db.commit()
        db.close()
        tk.messagebox.showinfo('RECORD FORM ENTRY ', 'RECORD UPDATED SUCCESSFULLY!')

    def Back():
        company1.destroy()


    # --------------------BUTTONS---------------------
    update = tk.Button(rightframe,text='UPDATE', fg='blue', font=('arial', 12, 'bold'), command=Update)
    update.place(relx=0, rely=0, relwidth=1, relheight=0.33)
    exit = tk.Button(rightframe, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
    exit.place(relx=0, rely=0.35, relwidth=1, relheight=0.33)
    display = tk.Button( rightframe,text='DISPLAY DATA', fg='blue', font=('arial', 12, 'bold'), command=Display)
    display.place(relx=0, rely=0.7, relwidth=1., relheight=0.33)


    #company1.mainloop()

# --------------PERSONAL INFO-----------------------------
def personal():
    personalroot = tk.Toplevel()
    personalroot.title('ACCOUNT INFORMATION')
    canvas = tk.Canvas(personalroot, height=400,width=800, bg='red')
    canvas.pack()
    mainframe = tk.Frame(personalroot, bg='white')
    mainframe.place(relx=0.5, rely=0, relwidth=0.6, relheight=0.8, anchor='n')
    rightframe=tk.Frame(personalroot, bg='white')
    rightframe.place(relx=0.8, rely=0.2, relwidth=0.2, relheight=0.4)

# -------------BUTTONS----------------------------------




    def Display():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        cursor.execute('SELECT email FROM userw where username like "%avougiouklo"')
        data= cursor.fetchall()
        cursor.execute('SELECT password FROM userw where username like "%avougiouklo"')
        passworddata = cursor.fetchall()

        emailentry.delete(0,END)
        emailentry.insert(END,data)
        '''passwdentry.delete(0,END)
        passwdentry.insert(END, passworddata)'''
        db.commit()
        db.close()

    displaybut = tk.Button(rightframe, text='DISPLAY EMAIL', fg='red', font=('arial', 12, 'bold'), command=Display)
    displaybut.place(relx=0, rely=0.5, relwidth=1, relheight=0.5)

    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        if (newpasswdentry.get() == passwdentry.get()):
            cursor.execute('update staff.userw set email=%s, password=%s where username like "%avougiouklo" ',(

            emailentry.get(),
            passwdentry.get()
            #newpasswdentry.get()
            ))
            tk.messagebox.showinfo("PASSWORD/EMAIL UPDATE","PASSWORD/EMAIL UPDATED SUCCESSFULLY")
        else:
            newpasswdentry.delete(0,END)
            passwdentry.delete(0,END)

            tk.messagebox.showerror("PASSWORD CONFIRMATION FAILURE", "THE TWO FIELDS MUST MATCH")
        db.commit()
        db.close()
    updatebut = tk.Button(rightframe, text='UPDATE INFO', fg='red', font=('arial', 12, 'bold'), command=Update)
    updatebut.place(relx=0, rely=0, relwidth=1, relheight=0.49)

# -----------LABELS AND ENTRIES----------------
    emailstr = StringVar()
    passwordstr = StringVar()
    newpasswordstr = StringVar()
    email = tk.Label(mainframe, text='EMAIL', fg='red', font=('arial', 12, 'bold'), bd=7)
    email.grid(row=0, column=0, sticky='W', padx=5)
    emailentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=emailstr)
    emailentry.grid(row=0, column=1, sticky='W', padx=5)

    passwd = tk.Label(mainframe, text='NEW PASSWORD', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd.grid(row=2, column=0, sticky='W', padx=5)
    passwdentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=passwordstr)
    passwdentry.grid(row=2, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(mainframe, text='RETYPE NEW PASSWORD', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=4, column=0, sticky='W', padx=5)
    newpasswdentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=newpasswordstr)
    newpasswdentry.grid(row=4, column=1, sticky='W', padx=5)





    #personalroot.mainloop()

    # --------------------EMPLOYEE-------------------
def Employee():
    employee1 = tk.Toplevel()
    employee1.title('EMPLOYEE INFORMATION')
    canvas = tk.Canvas(employee1, width=800, height=650, bg='blue')
    canvas.pack()
    mainframe = tk.Frame(employee1, bg='white')
    mainframe.place(relx=0, rely=0, relwidth=0.8, relheight=0.5)
    bottomframe = tk.Frame(employee1, bg='white')
    bottomframe.place(relx=0, rely=0.51, relwidth=1, relheight=0.49)

    rightframe = tk.Frame(employee1, bg='white')
    rightframe.place(relx=0.81, rely=0, relwidth=0.2, relheight=0.5)



    # ------ VARIABLE DECLARATION---------
    AFM = StringVar()
    DOY = StringVar()
    NAME = StringVar()
    PHONE = StringVar()
    STREET = StringVar()
    POSITION = StringVar()
    GRADE = StringVar()
    EVFIRST = StringVar()
    EVLAST = StringVar()

    # -----------DOUBLE CLICK EVENT-------------
    def Treeinfo(ev):
        viewinfo = records.focus()
        Datadisplay = records.item(viewinfo)
        row = Datadisplay['values']
        print(row[2])
        firstnameentry.delete(0,END)
        firstnameentry.insert(END,row[0])
        lastentry.delete(0,END)
        lastentry.insert(END,row[1])
        usernameentry.delete(0, END)
        usernameentry.insert(END, row[2])
        bioentry.delete(0, END)
        bioentry.insert(END, row[3])
        statisticsentry.delete(0,END)
        statisticsentry.insert(END,row[4])
        certificatesentry.delete(0,END)
        certificatesentry.insert(END,row[5])
        awardsentry.delete(0,END)
        awardsentry.insert(END,row[6])

    firstname = tk.Label(mainframe, text='FirstName', fg='red', font=('arial', 12, 'bold'), bd=7)
    firstname.grid(row=0, column=0, sticky='W', padx=5)
    firstnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=AFM)
    firstnameentry.grid(row=0, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(mainframe, text='LastName', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=1, column=0, sticky='W', padx=5)
    lastentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    lastentry.grid(row=1, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(mainframe, text='Username', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=2, column=0, sticky='W', padx=5)
    usernameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    usernameentry.grid(row=2, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(mainframe, text='Bio', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=3, column=0, sticky='W', padx=5)
    bioentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    bioentry.grid(row=3, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(mainframe, text='Statistics', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=4, column=0, sticky='W', padx=5)
    statisticsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    statisticsentry.grid(row=4, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(mainframe, text='Certificates', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=5, column=0, sticky='W', padx=5)
    certificatesentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    certificatesentry.grid(row=5, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(mainframe, text='Awards', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=6, column=0, sticky='W', padx=5)
    awardsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    awardsentry.grid(row=6, column=1, sticky='W', padx=5)





    # ---------TREEVIEW---------

    scrollbar = Scrollbar(bottomframe, orient=VERTICAL)
    records = ttk.Treeview(bottomframe, yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns'] = ('AFM','DOY', 'NUM', 'CITY' ,'NAME', 'PHONE', 'STREET')

    records.column('AFM', width=50)
    records.column('DOY', width=50)
    records.column('NUM', width=50)
    records.column('CITY', width=50)
    records.column('NAME', width=50)
    records.column('PHONE', width=50)
    records.column('STREET', width=50)



    records['show']='headings'

    records.heading('AFM', text='Employees FirstName')
    records.heading('DOY', text='Employees LastName')
    records.heading('NUM', text='Username')
    records.heading('CITY', text='Bio')
    records.heading('NAME', text='Statistics')
    records.heading('PHONE', text='Certificates')
    records.heading('STREET', text='Awards')



    records.pack(fill=BOTH)



    records.bind('<ButtonRelease-1>', Treeinfo)

    def Display():
        db = mysql.connector.connect(host='127.0.0.1', port='3306', user='root', password='123456', database='staff')
        cursor = db.cursor()
        cursor.execute('SELECT name,sumname,employee.username,bio,sustatikes,certificates,awards FROM employee inner join userw on userw.username=employee.username ')
        res = cursor.fetchall()
        #print(res)

        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                records.insert('', END, values=x)

        db.commit()
        db.close()

    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        cursor.execute('update staff.employee set sustatikes%=s,certificates%=s,awards%=s where firstname%=s and sumname%=s', (


            statisticsentry.get(),
            certificatesentry.get(),
            awardsentry.get(),
            firstnameentry.get(),
            lastentry.get()
        ))

        db.commit()
        db.close()
        tk.messagebox.showinfo('RECORD FORM ENTRY ', 'RECORD UPDATED SUCCESSFULLY!')


    def Search():
        try:
            db = mysql.connector.connect(host='localhost', user='root', password='123456', database='staff')
            cursor = db.cursor()
            cursor.execute('SELECT * FROM employee where firstname="%s" and sumname="%s"', firstnameentry.get(), lastentry.get())
            row = cursor.fetchall()

            AFM.set(row[0])
            DOY.set(row[1])
            '''
            NAME.set(row[2])
            PHONE.set(row[3])
            STREET.set(row[4])
            '''
            POSITION.set(row[5])
            GRADE.set(row[6])
            EVFIRST.set(row[7])
            EVLAST.set(row[8])



            db.commit()
            db.close()
        except:
            tk.messagebox.showinfo("NO SUCH RECORD")

    def Back():
        employee1.destroy()

        # --------BUTTONS-----------

    displaybut = tk.Button(rightframe, text='DISPLAY', fg='red', font=('arial', 12, 'bold'), command=Display)
    displaybut.place(relx=0, rely=0, relwidth=1, relheight=0.33)

    updatebutt = tk.Button(rightframe, text='UPDATE INFO', fg='red', font=('arial', 12, 'bold'), command=Update)
    updatebutt.place(relx=0, rely=0.34, relwidth=1, relheight=0.33)

    searchbutt = tk.Button(rightframe, text='BACK', fg='red', font=('arial', 12, 'bold'), command=Back)
    searchbutt.place(relx=0, rely=0.67, relwidth=1, relheight=.33)

# --------------JOB SALARY/EVALUATION WINDOW-------------------
def Job():
    jobroot = tk.Toplevel()
    jobroot.title("JOB SALARY/EVALUATION")
    canvas = tk.Canvas(jobroot, bg='red', width=800, height=600)
    canvas.pack()
    entriesframe1 = tk.Frame(jobroot, bg='white')
    entriesframe1.place(relx=0, rely=0, relwidth=0.79, relheight=0.5)
    treeframe = tk.Frame(jobroot, bg='red')
    treeframe.place(relx=0, rely=0.51, relwidth=1, relheight=0.49)
    rightframe = tk.Frame(jobroot, bg = 'white')
    rightframe.place(relx=0.8, rely=0, relwidth=0.2, relheight=0.5)
    # ---------ENTRIES AND LABELS--------------

    firstname = tk.Label(entriesframe1, text='POSITION', fg='red', font=('arial', 12, 'bold'), bd=7)
    firstname.grid(row=0, column=0, sticky='W', padx=5)
    positionentry = tk.Entry(entriesframe1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    positionentry.grid(row=0, column=1, sticky='W', padx=5)

    firstname = tk.Label(entriesframe1, text='SALARY', fg='red', font=('arial', 12, 'bold'), bd=7)
    firstname.grid(row=1, column=0, sticky='W', padx=5)
    salaryentry = tk.Entry(entriesframe1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    salaryentry.grid(row=1, column=1, sticky='W', padx=5)

    # ---------------DISPLAY AND UPDATE FUNCTIONS---------------------
    def Display():
        db = mysql.connector.connect(host='127.0.0.1', port='3306', user='root', password='123456', database='staff')
        cursor = db.cursor()
        cursor.execute('SELECT position,salary FROM job')
        res = cursor.fetchall()


        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                records.insert('', END, values=x)

        db.commit()
        db.close()

    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        cursor.execute('update staff.job set salary=%s where position=%s',(


        salaryentry.get(),
        positionentry.get()
        ))





        db.commit()
        db.close()
        tk.messagebox.showinfo('RECORD FORM ENTRY ', 'RECORD UPDATED SUCCESSFULLY!')

    # ---------BUTTONS---------------
    salarybut = tk.Button(rightframe,  text='CHANGE SALARY', fg='red', font=('arial', 12, 'bold'), command=Update)
    salarybut.place(relx=0, rely=0, relwidth=1, relheight=0.33)

    displaybut = tk.Button(rightframe, text='DISPLAY DATA', fg='red', font=('arial', 12, 'bold'), command=Display)
    displaybut.place(relx=0, rely=0.34, relwidth=1, relheight=0.33)

    # -------------TreeView------------------
    scrollbar = Scrollbar(treeframe, orient=VERTICAL)
    records = ttk.Treeview(treeframe, yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns'] = ('AFM', 'DOY')

    records.column('AFM', width=50)
    records.column('DOY', width=50)


    records['show'] = 'headings'

    records.heading('AFM', text='POSITION')
    records.heading('DOY', text='SALARY')


    records.pack(fill=BOTH)
    def Treeinfo(ev):
        viewinfo = records.focus()
        Datadisplay = records.item(viewinfo)
        row = Datadisplay['values']
        positionentry.delete(0,END)
        positionentry.insert(END,row[0])
        salaryentry.delete(0,END)
        salaryentry.insert(END,row[1])

    records.bind('<ButtonRelease-1>', Treeinfo)

def Searchgui():
    searchroot = tk.Toplevel()
    searchroot.title("SEARCH EMPLOYEE")
    canvas = tk.Canvas(searchroot, bg='red', width=800, height=600)
    canvas.pack()
    entriesframe1 = tk.Frame(searchroot, bg='white')
    entriesframe1.place(relx=0, rely=0, relwidth=0.79, relheight=0.5)
    treeframe = tk.Frame(searchroot, bg='red')
    treeframe.place(relx=0, rely=0.51, relwidth=1, relheight=0.49)
    rightframe = tk.Frame(searchroot, bg='white')
    rightframe.place(relx=0.8, rely=0, relwidth=0.2, relheight=0.5)

    firstname = tk.Label(entriesframe1, text='FirstName', fg='red', font=('arial', 12, 'bold'), bd=7)
    firstname.grid(row=0, column=0, sticky='W', padx=5)
    firstnameentry = tk.Entry(entriesframe1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    firstnameentry.grid(row=0, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(entriesframe1, text='LastName', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=1, column=0, sticky='W', padx=5)
    lastentry = tk.Entry(entriesframe1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    lastentry.grid(row=1, column=1, sticky='W', padx=5)




    def Treeinfo(ev):
        viewinfo = records.focus()
        Datadisplay = records.item(viewinfo)
        row = Datadisplay['values']
        firstnameentry.delete(0, END)
        firstnameentry.insert(END, row[0])
        lastentry.delete(0, END)
        lastentry.insert(END, row[1])



    # -------------TreeView------------------
    scrollbar = Scrollbar(treeframe, orient=VERTICAL)
    records = ttk.Treeview(treeframe, yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns'] = ('AFM', 'DOY')

    records.column('AFM', width=50)
    records.column('DOY', width=50)

    records['show'] = 'headings'

    records.heading('AFM', text='FIRSTNAME')
    records.heading('DOY', text='LASTNAME')

    records.pack(fill=BOTH)
    records.bind('<ButtonRelease-1>', Treeinfo)

    def Display():
        db = mysql.connector.connect(host='127.0.0.1', port='3306', user='root', password='123456', database='staff')
        cursor = db.cursor()
        cursor.execute('SELECT name,sumname FROM userw')
        res = cursor.fetchall()

        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                records.insert('', END, values=x)

        db.commit()
        db.close()

    Display()


    def Search():
        db = mysql.connector.connect(host='127.0.0.1', port='3306', user='root', password='123456', database='staff')
        cursor = db.cursor()
        cursor.execute('call getEvaluation(%s,%s )' ,(firstnameentry.get(),
                                                      lastentry.get())
         )
        res = cursor.fetchall()
        print(res)

    salarybut = tk.Button(rightframe, text='SEARCH FOR EMPLOYEE', fg='red', font=('arial', 12, 'bold'), command=Search)
    salarybut.place(relx=0, rely=0, relwidth=1, relheight=0.33)

    def Back():
        searchroot.destroy()

    displaybut = tk.Button(rightframe, text='BACK', fg='red', font=('arial', 12, 'bold'), command=Back)
    displaybut.place(relx=0, rely=0.34, relwidth=1, relheight=0.33)


#managerpage()

