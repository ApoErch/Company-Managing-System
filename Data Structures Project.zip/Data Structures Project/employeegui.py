import tkinter as tk
from tkinter import *
from tkinter import ttk, messagebox
import mysql.connector





def employeepage():
    root = tk.Tk()
    root.title("EMPLOYEE")
    canvas = tk.Canvas(root, bg='red', height=600, width=1067)
    canvas.pack()
    label = tk.Label(root, text='EMPLOYEE ACCOUNT', fg='red', font=100)
    label.place(relx=0.42, rely=0.1)

    comp_button = tk.Button(root, text='EMPLOYEE INFO', fg='red', command=employeeinfo)
    comp_button.place(relx=0.1, rely=0.35, relwidth=0.2, relheight=0.1)

    personal_button = tk.Button(root, text='APPLY FOR A PROMOTION', fg='red', command=Jobs)
    personal_button.place(relx=0.4, rely=0.35, relwidth=0.2, relheight=0.1)

    employee_button = tk.Button(root, text='JOB APPLICATIONS', fg='red', command=showjobappliances)
    employee_button.place(relx=0.7, rely=0.35, relwidth=0.2, relheight=0.1)

    # evaluation_button = tk.Button(root, text='REMOVE JOB APPLICATION', fg='red')
    # evaluation_button.place(relx=0.4, rely=0.6, relwidth=0.2, relheight=0.1)

    root.mainloop()


def employeeinfo():
    root = tk.Toplevel()
    root.title("EMPLOYEE INFO")

    canvas = tk.Canvas(root, bg='yellow', width=650, height=600)
    canvas.pack()

    mainframe = tk.Frame(root, bg='white')
    mainframe.place(relx=0, rely=0, relwidth=1, relheight=1)

    username = tk.Label(mainframe, text='USERNAME', fg='red', font=('arial', 12, 'bold'), bd=7)
    username.grid(row=0, column=0, sticky='W', padx=5)
    usernameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    usernameentry.grid(row=0, column=1, sticky='W', padx=5)

    passwd1 = tk.Label(mainframe, text='PASSWORD', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd1.grid(row=1, column=0, sticky='W', padx=5)
    passwdentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    passwdentry.grid(row=1, column=1, sticky='W', padx=5)

    newpasswd1 = tk.Label(mainframe, text='FIRSTNAME', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd1.grid(row=2, column=0, sticky='W', padx=5)
    firstnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    firstnameentry.grid(row=2, column=1, sticky='W', padx=5)

    email2 = tk.Label(mainframe, text='LASTNAME', fg='red', font=('arial', 12, 'bold'), bd=7)
    email2.grid(row=3, column=0, sticky='W', padx=5)
    lastnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    lastnameentry.grid(row=3, column=1, sticky='W', padx=5)

    passwd2 = tk.Label(mainframe, text='REGISTER  DATE', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd2.grid(row=4, column=0, sticky='W', padx=5)
    registerdateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    registerdateentry.grid(row=4, column=1, sticky='W', padx=5)

    newpasswd3 = tk.Label(mainframe, text='EMAIL', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd3.grid(row=5, column=0, sticky='W', padx=5)
    emailentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    emailentry.grid(row=5, column=1, sticky='W', padx=5)

    email4 = tk.Label(mainframe, text='BIO', fg='red', font=('arial', 12, 'bold'), bd=7)
    email4.grid(row=6, column=0, sticky='W', padx=5)
    bioentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    bioentry.grid(row=6, column=1, sticky='W', padx=5)

    passwd4 = tk.Label(mainframe, text='STATISTICS', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd4.grid(row=7, column=0, sticky='W', padx=5)
    statisticsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    statisticsentry.grid(row=7, column=1, sticky='W', padx=5)

    newpasswd4 = tk.Label(mainframe, text='CERTIFICATES', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd4.grid(row=8, column=0, sticky='W', padx=5)
    certificatesentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    certificatesentry.grid(row=8, column=1, sticky='W', padx=5)

    passwd5 = tk.Label(mainframe, text='AWARDS', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=9, column=0, sticky='W', padx=5)
    awardsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    awardsentry.grid(row=9, column=1, sticky='W', padx=5)

    buttonback = tk.Button(mainframe, text='BACK', fg='red', font=('arial', 12, 'bold'), command='')
    buttonback.place(relx=0, rely=0.81, relwidth=0.5, relheight=0.19)

    def Display():
        db = mysql.connector.connect(host='localhost', port=3306, user='root', password='123456',
                                     database='staff')

        cursor2 = db.cursor()
        cursor2.execute('SELECT * FROM userw')  # -----PWS KANE TAUTOPOIHSH ME TO USERNAME EDW?????


        res2 = cursor2.fetchall()
        # ------------USERW INFO------------

        usernameentry.delete(0, END)
        usernameentry.insert(END, res2[0][0])
        passwdentry.delete(0, END)
        passwdentry.insert(END, res2[0][1])
        firstnameentry.delete(0, END)
        firstnameentry.insert(END, res2[0][2])
        lastnameentry.delete(0, END)
        lastnameentry.insert(END, res2[0][3])
        registerdateentry.delete(0, END)
        registerdateentry.insert(END, res2[0][4])
        emailentry.delete(0, END)
        emailentry.insert(END, res2[0][5])

        cursor1 = db.cursor()
        cursor1.execute('SELECT bio,sustatikes,certificates,awards FROM employee where username like "%avougiouklo"',(
                )) # -----PWS KANE TAUTOPOIHSH ME TO USERNAME EDW?????

        res1 = cursor1.fetchall()
        # ----------------EMPLOYEE INFO-------------
        #print(res1)
        bioentry.delete(0, END)
        bioentry.insert(END, res1[0])
        statisticsentry.delete(0, END)
        statisticsentry.insert(END, res1[0][1])
        certificatesentry.delete(0, END)
        certificatesentry.insert(END, res1[0][2])
        awardsentry.delete(0, END)
        awardsentry.insert(END, res1[0][3])



        db.commit()
        db.close()

    buttondisplay = tk.Button(mainframe, text='DISPLAY MY INFO', fg='red', font=('arial', 12, 'bold'), command=Display)
    buttondisplay.place(relx=0.55, rely=0.81, relwidth=0.4, relheight=0.19)

    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor1 = db.cursor()
        cursor1.execute('update staff.userw set email=%s, password=%s where username like "%avougiouklo" ', (
            emailentry.get(),
            passwdentry.get()  # PAIZEI NA MHN GINETAI GTI EXW KAI TO emailentry11

        ))
        '''cursor2 = db.cursor()
        cursor2.execute(
            'update employee set bio=%s ', (

                bioentry.get()

            ))'''

        db.commit()
        db.close()
        tk.messagebox.showinfo('RECORD FORM ENTRY ', 'RECORD UPDATED SUCCESSFULLY!')

    button = tk.Button(mainframe, text='UPDATE INFO', fg='red', font=('arial', 12, 'bold'), command=Update)
    button.place(relx=0, rely=0.6, relwidth=0.5, relheight=0.2)

    #root.mainloop()


def Jobs():
    jobsroot = tk.Toplevel()
    jobsroot.title("JOBS")
    canvas = tk.Canvas(jobsroot, bg='yellow', width=800, height=600)
    canvas.pack()
    mainframe = tk.Frame(jobsroot, bg='white')
    mainframe.place(relx=0, rely=0, relwidth=0.79, relheight=0.4)
    bottomframe = tk.Frame(jobsroot, bg='red')
    bottomframe.place(relx=0, rely=0.41, relwidth=1, relheight=0.59)
    rightframe = tk.Frame(jobsroot, bg='white')
    rightframe.place(relx=0.8, rely=0, relwidth=0.2, relheight=0.4)

    passwd5 = tk.Label(mainframe, text='JOB ID', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=0, column=0, sticky='W', padx=5)
    jobidentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    jobidentry.grid(row=0, column=1, sticky='W', padx=5)

    passwd5 = tk.Label(mainframe, text='POSITION', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=1, column=0, sticky='W', padx=5)
    positionentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    positionentry.grid(row=1, column=1, sticky='W', padx=5)

    passwd5 = tk.Label(mainframe, text='SALARY', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=2, column=0, sticky='W', padx=5)
    salaryentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    salaryentry.grid(row=2, column=1, sticky='W', padx=5)

    passwd5 = tk.Label(mainframe, text='STATUS', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=3, column=0, sticky='W', padx=5)
    statusentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    statusentry.grid(row=3, column=1, sticky='W', padx=5)

    # ON CLICK TREEVIEW EVENT-------------
    def onclickevent(ev):
        viewinfo = records.focus()
        data = records.item(viewinfo)

        row = data['values']
        print(row)

        jobidentry.delete(0, END)
        jobidentry.insert(END, row[0])
        positionentry.delete(0, END)
        positionentry.insert(END, row[1])
        salaryentry.delete(0, END)
        salaryentry.insert(END, row[2])
        statusentry.delete(0, END)
        statusentry.insert(END, row[3])

    # ----------TREEVIEW-----------------
    scrollbar = Scrollbar(bottomframe, orient=VERTICAL)
    records = ttk.Treeview(bottomframe, yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns'] = ('AFM', 'DOY', 'NAME', 'PHONE')

    records.column('AFM', width=60)
    records.column('DOY', width=60)
    records.column('NAME', width=60)
    records.column('PHONE', width=60)

    records['show'] = 'headings'

    records.heading('AFM', text='Job ID')
    records.heading('DOY', text='Position')
    records.heading('NAME', text='Salary')
    records.heading('PHONE', text='Status')

    records.pack(fill=BOTH, expand=1)
    records.bind('<ButtonRelease-1>', onclickevent)

    def Display():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor1 = db.cursor()
        cursor1.execute('select id,position,salary,status from staff.job  ')
        res = cursor1.fetchall()

        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                # print(x)

                records.insert('', END, values=x)
        db.commit()
        db.close()

    Display()

    def Apply():
        username='avougiouklo'
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor1 = db.cursor()
        cursor1.execute('insert into applies(username, job_id,job_applie,status) values (%s,%s,%s,%s)',(
            username,
            jobidentry.get(),
            positionentry.get(),
            statusentry.get()

        ))

        db.commit()
        db.close()

    def Back():
        jobsroot.destroy()

    backbutton = tk.Button(rightframe, text='APPLY FOR JOB', fg='red', font=('arial', 12, 'bold'), command=Apply)
    backbutton.place(relx=0, rely=0.0, relwidth=1, relheight=0.49)

    backbutton = tk.Button(rightframe, text='BACK', fg='red', font=('arial', 12, 'bold'), command=Back)
    backbutton.place(relx=0, rely=0.51, relwidth=1, relheight=0.49)

    #jobsroot.mainloop()

def showjobappliances():
    jobsroot = tk.Toplevel()
    jobsroot.title("MY APPLIANCES")
    canvas = tk.Canvas(jobsroot, bg='yellow', width=800, height=600)
    canvas.pack()
    mainframe = tk.Frame(jobsroot, bg='white')
    mainframe.place(relx=0, rely=0, relwidth=0.79, relheight=0.4)
    bottomframe = tk.Frame(jobsroot, bg='red')
    bottomframe.place(relx=0, rely=0.41, relwidth=1, relheight=0.59)
    rightframe = tk.Frame(jobsroot, bg='white')
    rightframe.place(relx=0.8, rely=0, relwidth=0.2, relheight=0.4)

    passwd5 = tk.Label(mainframe, text='JOB ID', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=0, column=0, sticky='W', padx=5)
    jobidentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    jobidentry.grid(row=0, column=1, sticky='W', padx=5)

    passwd5 = tk.Label(mainframe, text='POSITION', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=1, column=0, sticky='W', padx=5)
    positionentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    positionentry.grid(row=1, column=1, sticky='W', padx=5)

    passwd5 = tk.Label(mainframe, text='SALARY', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=2, column=0, sticky='W', padx=5)
    salaryentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    salaryentry.grid(row=2, column=1, sticky='W', padx=5)

    passwd5 = tk.Label(mainframe, text='STATUS', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=3, column=0, sticky='W', padx=5)
    statusentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    statusentry.grid(row=3, column=1, sticky='W', padx=5)

    # ON CLICK TREEVIEW EVENT-------------
    def onclickevent(ev):
        viewinfo = records.focus()
        data = records.item(viewinfo)

        row = data['values']


        jobidentry.delete(0, END)
        jobidentry.insert(END, row[0])
        positionentry.delete(0, END)
        positionentry.insert(END, row[1])
        salaryentry.delete(0, END)
        salaryentry.insert(END, row[2])
        statusentry.delete(0, END)
        statusentry.insert(END, row[3])

    # ----------TREEVIEW-----------------
    scrollbar = Scrollbar(bottomframe, orient=VERTICAL)
    records = ttk.Treeview(bottomframe, yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns'] = ('AFM', 'DOY', 'NAME', 'PHONE')

    records.column('AFM', width=60)
    records.column('DOY', width=60)
    records.column('NAME', width=60)
    records.column('PHONE', width=60)

    records['show'] = 'headings'

    records.heading('AFM', text='Job ID')
    records.heading('DOY', text='Position')
    records.heading('NAME', text='Salary')
    records.heading('PHONE', text='Status')

    records.pack(fill=BOTH, expand=1)
    records.bind('<ButtonRelease-1>', onclickevent)

    def Display():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor1 = db.cursor()
        cursor1.execute('select job_id,job_applie,salary,applies.status from staff.applies inner join job on job.id=applies.job_id where username like "%avougiouklo"',(

        )
                        )
        res = cursor1.fetchall()

        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                # print(x)

                records.insert('', END, values=x)
        db.commit()
        db.close()

    Display()

    def Delete():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor1 = db.cursor()
        cursor1.execute('delete  from staff.applies   where job_id=  '+ jobidentry.get(),

        )
        db.commit()
        db.close()
        tk.messagebox.showinfo("APPLICATION DELETION","JOB APPLICATION DELETED SUCCESSFULLY")

    def Back():
        jobsroot.destroy()

    deletebutt = tk.Button(rightframe, text='DELETE APPLIANCE', fg='red', font=('arial', 12, 'bold'), command=Delete)
    deletebutt.place(relx=0, rely=0, relwidth=1, relheight=0.5)

    backbutton = tk.Button(rightframe, text='BACK', fg='red', font=('arial', 12, 'bold'), command=Back)
    backbutton.place(relx=0, rely=0.51, relwidth=1, relheight=0.49)
#employeepage()

