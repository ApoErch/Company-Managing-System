import tkinter as tk
from tkinter import *
from tkinter import ttk, messagebox
import mysql.connector
import datetime













def adminmainpage():
    root = tk.Tk()
    root.title("ADMIN PAGE")
    canvas = tk.Canvas(root, width=600, height=400)

    canvas.pack()
    frame = tk.Frame(root)
    frame.place(relx=0, rely=0, relwidth=1, relheight=1)

    # -------------CHECKBOX----------

    def usercheckbox():
        master = tk.Toplevel()
        master.title("USER CREATION")
        master.geometry('400x250')
        '''canvas = tk.Canvas(master, height=200, width=200)
        canvas.pack()
        frame = tk.Frame(master, height=100, width=200)
        frame.pack()'''

        # ------------CHECKBOX SELECTION-----------------
        def click_me():

            if var1.get() == 1 and var2.get() == 0 and var3.get() == 0:

                newemployee()
            elif var1.get() == 0 and var2.get() == 1 and var3.get() == 0:
                newmanager()
            elif var1.get() == 0 and var2.get() == 0 and var3.get() == 1:
                newevaluator()

            else:
                tk.messagebox.showerror("CHECKBOX ERROR", "PLEASE SELECT ONLY ONE OF THE GIVEN OPTIONS")

        def newevaluator():
            master.destroy()
            employeeroot = tk.Toplevel()
            employeeroot.title("EVALUATOR REGISTRATION")
            canvas = tk.Canvas(employeeroot, width=600, height=450)
            canvas.pack()
            mainframe = tk.Frame(employeeroot, bg='red')
            mainframe.place(relx=0, rely=0, relheight=1, relwidth=1)

            # --------------ENTRIES AND LABELS-------------------

            num = tk.Label(mainframe, text='Username', fg='red', font=('arial', 12, 'bold'), bd=7)
            num.grid(row=0, column=0, sticky='W', padx=5)
            userentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            userentry.grid(row=0, column=1, sticky='W', padx=5)

            nu2 = tk.Label(mainframe, text='Password', fg='red', font=('arial', 12, 'bold'), bd=7)
            nu2.grid(row=1, column=0, sticky='W', padx=5)
            passwdentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            passwdentry.grid(row=1, column=1, sticky='W', padx=5)

            num3 = tk.Label(mainframe, text='FirstName', fg='red', font=('arial', 12, 'bold'), bd=7)
            num3.grid(row=2, column=0, sticky='W', padx=5)
            firstnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            firstnameentry.grid(row=2, column=1, sticky='W', padx=5)

            num4 = tk.Label(mainframe, text='LastName', fg='red', font=('arial', 12, 'bold'), bd=7)
            num4.grid(row=3, column=0, sticky='W', padx=5)
            lastnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            lastnameentry.grid(row=3, column=1, sticky='W', padx=5)

            num6 = tk.Label(mainframe, text='Email', fg='red', font=('arial', 12, 'bold'), bd=7)
            num6.grid(row=4, column=0, sticky='W', padx=5)
            emailentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            emailentry.grid(row=4, column=1, sticky='W', padx=5)

            num7 = tk.Label(mainframe, text=' Years of Experience', fg='red', font=('arial', 12, 'bold'), bd=7)
            num7.grid(row=5, column=0, sticky='W', padx=5)
            expyearsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            expyearsentry.grid(row=5, column=1, sticky='W', padx=5)

            num8 = tk.Label(mainframe, text='Firm', fg='red', font=('arial', 12, 'bold'), bd=7)
            num8.grid(row=6, column=0, sticky='W', padx=5)
            firmentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            firmentry.grid(row=6, column=1, sticky='W', padx=5)

            def Adduserevaluator():
                db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
                cursor1 = db.cursor()

                try:

                    cursor1.execute(
                        'insert into staff.userw(username,password,name,sumname,reg_date,email) values (%s,%s,%s,%s,%s,%s)',
                        (

                            userentry.get(),
                            passwdentry.get(),
                            firstnameentry.get(),
                            lastnameentry.get(),
                            datetime.datetime.now(),
                            emailentry.get()))




                except:
                    tk.messagebox.showerror(
                        ("ERROR", "USER WASNT REGISTERED.PLEASE CHECK THAT  ALL REQUIRED FIELDS ARE FILLED!"))

                statusstrevaluator = 'EVALUATOR'
                cursor1.execute('insert into status(user,status) values(%s,%s)',
                                (userentry.get(),
                                 statusstrevaluator))

                cursor1.execute(
                    'insert into staff.evaluator(username,exp_years,FIM) values(%s,%s,%s)', (
                        userentry.get(),
                        expyearsentry.get(),
                        firmentry.get()

                    ))

                db.commit()
                db.close()

            def Reset():
                userentry.delete(0, END)
                passwdentry.delete(0, END)
                firstnameentry.delete(0, END)
                lastnameentry.delete(0, END)
                emailentry.delete(0, END)
                expyearsentry.delete(0, END)
                firmentry.delete(0, END)

            # ---------BUTTONS--------------

            addbutt = tk.Button(mainframe, text='ADD USER', fg='blue', font=('arial', 12, 'bold'),
                                command=Adduserevaluator)
            addbutt.place(relx=0.001, rely=0.8, relwidth=0.3, relheight=0.19)

            addbutt = tk.Button(mainframe, text='RESET', fg='blue', font=('arial', 12, 'bold'), command=Reset)
            addbutt.place(relx=0.32, rely=0.8, relwidth=0.3, relheight=0.19)

            def Back():
                employeeroot.destroy()

            addbutt = tk.Button(mainframe, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
            addbutt.place(relx=0.64, rely=0.8, relwidth=0.3, relheight=0.19)

        def newmanager():
            master.destroy()
            employeeroot = tk.Toplevel()
            employeeroot.title("MANAGER REGISTRATION")
            canvas = tk.Canvas(employeeroot, width=600, height=450)
            canvas.pack()
            mainframe = tk.Frame(employeeroot, bg='red')
            mainframe.place(relx=0, rely=0, relheight=1, relwidth=1)

            # --------------ENTRIES AND LABELS-------------------

            num = tk.Label(mainframe, text='Username', fg='red', font=('arial', 12, 'bold'), bd=7)
            num.grid(row=0, column=0, sticky='W', padx=5)
            userentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            userentry.grid(row=0, column=1, sticky='W', padx=5)

            nu2 = tk.Label(mainframe, text='Password', fg='red', font=('arial', 12, 'bold'), bd=7)
            nu2.grid(row=1, column=0, sticky='W', padx=5)
            passwdentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            passwdentry.grid(row=1, column=1, sticky='W', padx=5)

            num3 = tk.Label(mainframe, text='FirstName', fg='red', font=('arial', 12, 'bold'), bd=7)
            num3.grid(row=2, column=0, sticky='W', padx=5)
            firstnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            firstnameentry.grid(row=2, column=1, sticky='W', padx=5)

            num4 = tk.Label(mainframe, text='LastName', fg='red', font=('arial', 12, 'bold'), bd=7)
            num4.grid(row=3, column=0, sticky='W', padx=5)
            lastnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            lastnameentry.grid(row=3, column=1, sticky='W', padx=5)

            num6 = tk.Label(mainframe, text='Email', fg='red', font=('arial', 12, 'bold'), bd=7)
            num6.grid(row=4, column=0, sticky='W', padx=5)
            emailentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            emailentry.grid(row=4, column=1, sticky='W', padx=5)

            num7 = tk.Label(mainframe, text='Years of Experience', fg='red', font=('arial', 12, 'bold'), bd=7)
            num7.grid(row=5, column=0, sticky='W', padx=5)
            expyearsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            expyearsentry.grid(row=5, column=1, sticky='W', padx=5)

            num8 = tk.Label(mainframe, text='Firm', fg='red', font=('arial', 12, 'bold'), bd=7)
            num8.grid(row=6, column=0, sticky='W', padx=5)
            firmentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            firmentry.grid(row=6, column=1, sticky='W', padx=5)

            def Addusermanager():
                db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
                cursor1 = db.cursor()

                try:

                    cursor1.execute(
                        'insert into staff.userw(username,password,name,sumname,reg_date,email) values (%s,%s,%s,%s,%s,%s)',
                        (

                            userentry.get(),
                            passwdentry.get(),
                            firstnameentry.get(),
                            lastnameentry.get(),
                            datetime.datetime.now(),
                            emailentry.get()))




                except:
                    tk.messagebox.showerror(
                        ("ERROR", "USER WASNT REGISTERED.PLEASE CHECK THAT  ALL REQUIRED FIELDS ARE FILLED!"))

                statusstrmanager = 'MANAGER'
                cursor1.execute('insert into status(user,status) values(%s,%s)',
                                (userentry.get(),
                                 statusstrmanager))

                cursor1.execute(
                    'insert into staff.manager(managerUsername,exp_years,FIM) values(%s,%s,%s)', (
                        userentry.get(),
                        expyearsentry.get(),
                        firmentry.get()

                    ))

                db.commit()
                db.close()

            def Reset():
                userentry.delete(0, END)
                passwdentry.delete(0, END)
                firstnameentry.delete(0, END)
                lastnameentry.delete(0, END)
                emailentry.delete(0, END)
                expyearsentry.delete(0, END)
                firmentry.delete(0, END)

            # ---------BUTTONS--------------

            addbutt = tk.Button(mainframe, text='ADD USER', fg='blue', font=('arial', 12, 'bold'),
                                command=Addusermanager)
            addbutt.place(relx=0.001, rely=0.8, relwidth=0.3, relheight=0.19)

            addbutt = tk.Button(mainframe, text='RESET', fg='blue', font=('arial', 12, 'bold'), command=Reset)
            addbutt.place(relx=0.32, rely=0.8, relwidth=0.3, relheight=0.19)

            def Back():
                employeeroot.destroy()

            addbutt = tk.Button(mainframe, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
            addbutt.place(relx=0.64, rely=0.8, relwidth=0.3, relheight=0.19)

        def newemployee():
            master.destroy()
            employeeroot = tk.Toplevel()
            employeeroot.title("EMPLOYEE REGISTRATION")
            canvas = tk.Canvas(employeeroot, width=600, height=450)
            canvas.pack()
            mainframe = tk.Frame(employeeroot, bg='red')
            mainframe.place(relx=0, rely=0, relheight=1, relwidth=1)

            # --------------ENTRIES AND LABELS-------------------

            num = tk.Label(mainframe, text='Username', fg='red', font=('arial', 12, 'bold'), bd=7)
            num.grid(row=0, column=0, sticky='W', padx=5)
            userentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            userentry.grid(row=0, column=1, sticky='W', padx=5)

            nu2 = tk.Label(mainframe, text='Password', fg='red', font=('arial', 12, 'bold'), bd=7)
            nu2.grid(row=1, column=0, sticky='W', padx=5)
            passwdentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            passwdentry.grid(row=1, column=1, sticky='W', padx=5)

            num3 = tk.Label(mainframe, text='FirstName', fg='red', font=('arial', 12, 'bold'), bd=7)
            num3.grid(row=2, column=0, sticky='W', padx=5)
            firstnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            firstnameentry.grid(row=2, column=1, sticky='W', padx=5)

            num4 = tk.Label(mainframe, text='LastName', fg='red', font=('arial', 12, 'bold'), bd=7)
            num4.grid(row=3, column=0, sticky='W', padx=5)
            lastnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            lastnameentry.grid(row=3, column=1, sticky='W', padx=5)

            num6 = tk.Label(mainframe, text='Email', fg='red', font=('arial', 12, 'bold'), bd=7)
            num6.grid(row=4, column=0, sticky='W', padx=5)
            emailentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            emailentry.grid(row=4, column=1, sticky='W', padx=5)

            num7 = tk.Label(mainframe, text='Bio', fg='red', font=('arial', 12, 'bold'), bd=7)
            num7.grid(row=5, column=0, sticky='W', padx=5)
            bioentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            bioentry.grid(row=5, column=1, sticky='W', padx=5)

            num8 = tk.Label(mainframe, text='Statistics', fg='red', font=('arial', 12, 'bold'), bd=7)
            num8.grid(row=6, column=0, sticky='W', padx=5)
            statisticsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            statisticsentry.grid(row=6, column=1, sticky='W', padx=5)

            num9 = tk.Label(mainframe, text='Certificates', fg='red', font=('arial', 12, 'bold'), bd=7)
            num9.grid(row=7, column=0, sticky='W', padx=5)
            certificatesentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            certificatesentry.grid(row=7, column=1, sticky='W', padx=5)

            num10 = tk.Label(mainframe, text='Awards', fg='red', font=('arial', 12, 'bold'), bd=7)
            num10.grid(row=8, column=0, sticky='W', padx=5)
            awardsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            awardsentry.grid(row=8, column=1, sticky='W', padx=5)

            # ---------------ADD USER - RESET - BACK-----------------

            def Adduseremployee():
                db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
                cursor1 = db.cursor()

                try:

                    cursor1.execute(
                        'insert into staff.userw(username,password,name,sumname,reg_date,email) values (%s,%s,%s,%s,%s,%s)',
                        (

                            userentry.get(),
                            passwdentry.get(),
                            firstnameentry.get(),
                            lastnameentry.get(),
                            datetime.datetime.now(),
                            emailentry.get()))




                except:
                    tk.messagebox.showerror(
                        ("ERROR", "USER WASNT REGISTERED.PLEASE CHECK THAT  ALL REQUIRED FIELDS ARE FILLED!"))
                statusstr = 'EMPLOYEE'
                cursor1.execute('insert into status(user,status) values(%s,%s)',
                                (userentry.get(),
                                 statusstr))

                cursor1.execute(
                    'insert into staff.employee(username,bio,sustatikes,certificates,awards) values(%s,%s,%s,%s,%s)', (
                        userentry.get(),
                        bioentry.get(),
                        statisticsentry.get(),
                        certificatesentry.get(),
                        awardsentry.get())

                    )

                db.commit()
                db.close()

            def Reset():
                userentry.delete(0, END)
                passwdentry.delete(0, END)
                firstnameentry.delete(0, END)
                lastnameentry.delete(0, END)
                emailentry.delete(0, END)
                bioentry.delete(0, END)
                statisticsentry.delete(0, END)
                certificatesentry.delete(0, END)
                awardsentry.delete(0, END)

            # ---------BUTTONS--------------

            addbutt = tk.Button(mainframe, text='ADD USER', fg='blue', font=('arial', 12, 'bold'),
                                command=Adduseremployee)
            addbutt.place(relx=0.001, rely=0.8, relwidth=0.3, relheight=0.19)

            addbutt = tk.Button(mainframe, text='RESET', fg='blue', font=('arial', 12, 'bold'), command=Reset)
            addbutt.place(relx=0.32, rely=0.8, relwidth=0.3, relheight=0.19)

            def Back():
                employeeroot.destroy()

            addbutt = tk.Button(mainframe, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
            addbutt.place(relx=0.64, rely=0.8, relwidth=0.3, relheight=0.19)

            #employeeroot.mainloop()

        label1 = tk.Label(master, text="PLEASE SELECT ONLY ONE OF THE FOLLOWING:", font=('arial', 12, 'bold'), bd=7)
        label1.grid(row=0, column=0, )

        var1 = tk.IntVar()

        employeecheckbut = tk.Checkbutton(master, text="EMPLOYEE", variable=var1, onvalue=1, offvalue=0,
                                          font=('arial', 12, 'bold'), bd=7)
        employeecheckbut.grid(row=1, sticky=W)

        var2 = tk.IntVar()
        managercheckbut = tk.Checkbutton(master, text="MANAGER", variable=var2, onvalue=1, offvalue=0,
                                         font=('arial', 12, 'bold'), bd=7)
        managercheckbut.grid(row=2, sticky=W)
        var3 = tk.IntVar()
        evaluatorcheckbut = tk.Checkbutton(master, text="EVALUATOR", variable=var3, onvalue=1, offvalue=0,
                                           font=('arial', 12, 'bold'), bd=7)
        evaluatorcheckbut.grid(row=3, sticky=W)
        Button(master, text='Cancel', font=('arial', 12, 'bold'), command=master.destroy).grid(row=5, column=0,
                                                                                               sticky=W, pady=4)
        Button(master, text='Confirm', font=('arial', 12, 'bold'), command=click_me).grid(row=4, column=0, sticky=W,
                                                                                          pady=4)
        #master.mainloop()

    # ----------------------NEW COMPANY------------------------------------------------------------------------

    def newcompany():
        companyroot = tk.Toplevel()
        companyroot.title("EVALUATOR REGISTRATION")
        canvas = tk.Canvas(companyroot, width=600, height=450)
        canvas.pack()
        mainframe = tk.Frame(companyroot, bg='red')
        mainframe.place(relx=0, rely=0, relheight=1, relwidth=1)

        # --------------ENTRIES AND LABELS-------------------

        num = tk.Label(mainframe, text='AFM', fg='red', font=('arial', 12, 'bold'), bd=7)
        num.grid(row=0, column=0, sticky='W', padx=5)
        afmentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        afmentry.grid(row=0, column=1, sticky='W', padx=5)

        nu2 = tk.Label(mainframe, text='DOY', fg='red', font=('arial', 12, 'bold'), bd=7)
        nu2.grid(row=1, column=0, sticky='W', padx=5)
        doyentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        doyentry.grid(row=1, column=1, sticky='W', padx=5)

        num3 = tk.Label(mainframe, text='Name', fg='red', font=('arial', 12, 'bold'), bd=7)
        num3.grid(row=2, column=0, sticky='W', padx=5)
        nameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        nameentry.grid(row=2, column=1, sticky='W', padx=5)

        num4 = tk.Label(mainframe, text='Phone', fg='red', font=('arial', 12, 'bold'), bd=7)
        num4.grid(row=3, column=0, sticky='W', padx=5)
        phoneentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        phoneentry.grid(row=3, column=1, sticky='W', padx=5)

        num6 = tk.Label(mainframe, text='Street', fg='red', font=('arial', 12, 'bold'), bd=7)
        num6.grid(row=4, column=0, sticky='W', padx=5)
        streetentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        streetentry.grid(row=4, column=1, sticky='W', padx=5)

        num7 = tk.Label(mainframe, text='Number', fg='red', font=('arial', 12, 'bold'), bd=7)
        num7.grid(row=5, column=0, sticky='W', padx=5)
        numberentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        numberentry.grid(row=5, column=1, sticky='W', padx=5)

        num8 = tk.Label(mainframe, text='City', fg='red', font=('arial', 12, 'bold'), bd=7)
        num8.grid(row=6, column=0, sticky='W', padx=5)
        cityentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        cityentry.grid(row=6, column=1, sticky='W', padx=5)

        num8 = tk.Label(mainframe, text='Country', fg='red', font=('arial', 12, 'bold'), bd=7)
        num8.grid(row=7, column=0, sticky='W', padx=5)
        countryentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        countryentry.grid(row=7, column=1, sticky='W', padx=5)

        afm = tk.Label(mainframe, text='Title', fg='red', font=('arial', 12, 'bold'), bd=7)
        afm.grid(row=8, column=0, sticky='W', padx=5)
        titleentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        titleentry.grid(row=8, column=1, sticky='W', padx=5)

        afm = tk.Label(mainframe, text='Description', fg='red', font=('arial', 12, 'bold'), bd=7)
        afm.grid(row=9, column=0, sticky='W', padx=5)
        descriptionentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        descriptionentry.grid(row=9, column=1, sticky='W', padx=5)

        '''afm = tk.Label(mainframe, text='Belongs To', fg='red', font=('arial', 12, 'bold'), bd=7)
        afm.grid(row=10, column=0, sticky='W', padx=5)
        belongstoentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        belongstoentry.grid(row=10, column=1, sticky='W', padx=5)'''

        # ---------------ADD USER - RESET - BACK-----------------

        def Addcompany():
            db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
            cursor1 = db.cursor()

            cursor1.execute(
                'insert into staff.company(AFM,DOY,name,phone,street,num,city,country) values (%s,%s,%s,%s,%s,%s,%s,%s)',
                (

                    afmentry.get(),
                    doyentry.get(),
                    nameentry.get(),
                    phoneentry.get(),
                    streetentry.get(),
                    numberentry.get(),
                    cityentry.get(),
                    countryentry.get()))
            cursor1.execute('insert into staff.antikeim(title, descr,belong_to) values (%s,%s,%s)', (
                titleentry.get(),
                descriptionentry.get(),
                titleentry.get()

            ))

            '''except:
                tk.messagebox.showerror(
                    ("ERROR", "COMPANY WASNT REGISTERED.PLEASE CHECK THAT  ALL REQUIRED FIELDS ARE FILLED!"))'''

            db.commit()
            db.close()

        def Reset():
            afmentry.delete(0, END)
            doyentry.delete(0, END)
            nameentry.delete(0, END)
            phoneentry.delete(0, END)
            streetentry.delete(0, END)
            numberentry.delete(0, END)
            cityentry.delete(0, END)
            countryentry.delete(0, END)
            titleentry.delete(0, END)
            descriptionentry.delete(0, END)


        # ---------BUTTONS--------------

        addbutt = tk.Button(mainframe, text='ADD COMPANY', fg='blue', font=('arial', 12, 'bold'), command=Addcompany)
        addbutt.place(relx=0.001, rely=0.8, relwidth=0.3, relheight=0.19)

        addbutt = tk.Button(mainframe, text='RESET', fg='blue', font=('arial', 12, 'bold'), command=Reset)
        addbutt.place(relx=0.32, rely=0.8, relwidth=0.3, relheight=0.19)

        def Back():
            companyroot.destroy()

        addbutt = tk.Button(mainframe, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
        addbutt.place(relx=0.64, rely=0.8, relwidth=0.3, relheight=0.19)

        #companyroot.mainloop()

    userbut = tk.Button(frame, text='CREATE A NEW USER', fg='blue', font=('arial', 12, 'bold'), command=usercheckbox)
    userbut.place(relx=0.3, rely=0.15, relwidth=0.4, relheight=0.2)

    userbut = tk.Button(frame, text='CREATE A NEW COMPANY', fg='blue', font=('arial', 12, 'bold'), command=newcompany)
    userbut.place(relx=0.3, rely=0.51, relwidth=0.4, relheight=0.2)

    root.mainloop()


#adminmainpage()