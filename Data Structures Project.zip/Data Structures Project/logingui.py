









import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
import datetime
from tkinter import *
#==============================LOGINGUI===================================

roothaha = tk.Tk()

canvas = tk.Canvas(roothaha, height=600, width=1067, bg='#52ECDC')
canvas.pack()

bg_image = tk.PhotoImage(file='hands typing600.png')
bg_label = tk.Label(roothaha, image=bg_image)
bg_label.place(relwidth=1, relheight=1)
frame1 = tk.Frame(roothaha, bg='brown')
frame1.place(relx=0.5, rely=0.2, relwidth=0.7, relheight=0.1, anchor='n')
USERNAME = tk.StringVar()
label = tk.Label(frame1, text='User Name:', bg='yellow', font=40)
label.place(relx=0, relheight=1, relwidth=0.2)

entry_email = tk.Entry(frame1, bd=4, font=80, textvariable=USERNAME)
entry_email.place(relx=0.2, relheight=1, relwidth=0.8)

frame2 = tk.Frame(roothaha, bg='red')
frame2.place(relx=0.5, rely=0.4, relwidth=0.7, relheight=0.1, anchor='n')

label = tk.Label(frame2, text='Password:', bg='yellow', font=40)
label.place(relx=0, relheight=1, relwidth=0.2)

entry_passwd = tk.Entry(frame2, bd=4, show='*', font=80)
entry_passwd.place(relx=0.2, relheight=1, relwidth=0.8)

entry_passwd.delete(0, 'end')





def managerpage():
    roothaha.destroy()
    management= tk.Tk()
    management.title('MANAGER ACCOUNT')
    canvas = tk.Canvas(management, bg='red', height=600, width=1067)
    canvas.pack()
    label = tk.Label(management, text='MANAGER ACCOUNT',fg='red', font=100)
    label.place(relx=0.42, rely=0.1)

    def rootdestroy():
        management.destroy()
        company()


    comp_button = tk.Button(management, text='COMPANY INFO', fg='red', command=company)
    comp_button.place(relx=0.1, rely=0.35 ,relwidth=0.2, relheight=0.1)
    def delete_management(ev):
        management.destroy()
    personal_button = tk.Button(management, text='PERSONAL INFO', fg='red', command=personal, )
    personal_button.place(relx=0.4, rely=0.35 ,relwidth=0.2, relheight=0.1)





    employee_button = tk.Button(management, text='EMPLOYEE INFO', fg='red', command=Employee)
    employee_button.place(relx=0.7, rely=0.35, relwidth=0.2, relheight=0.1)

    evaluation_button = tk.Button(management, text='JOB SALARY', fg='red', command=Job)
    evaluation_button.place(relx=0.4, rely=0.6 ,relwidth=0.2, relheight=0.1)

    searchbutt = tk.Button(management, text='SEARCH FOR AN EMPLOYEE', fg='red', command=Searchgui)
    searchbutt.place(relx=0.1, rely=0.6 ,relwidth=0.2, relheight=0.1)

    def Logout():
        Exit = tk.messagebox.askyesno('LOGOUT', 'DO YOU REALLY WANT TO LOGOUT?', parent = management)
        if Exit > 0:
            management.destroy()
            return

    logoutbutt = tk.Button(management, text='LOGOUT', fg='red', command=Logout)
    logoutbutt.place(relx=0.7, rely=0.6, relwidth=0.2, relheight=0.1)

    #management.mainloop()



    # ---------------COMPANY----------------
def company():

    company1=tk.Toplevel()

    company1.title('COMPANY INFORMATION')
    canvas = tk.Canvas(company1, bg='red', height=600, width=1067)
    canvas.pack()
    frame1 = tk.Frame(company1, bg='white')
    frame1.place(relx=0.5, rely=0, relwidth=0.4, relheight=0.7, anchor='n')
    #label = tk.Label(company1, text='COMPANY INFO', fg='red', font=100)
    #label.place(relx=0.42, rely=0.1)
    bottomframe = tk.Frame(company1, bg='white')
    bottomframe.place(relx=0,rely=0.71, relwidth=0.8, relheight=0.3)
    rightframe = tk.Frame(company1, bg='yellow')
    rightframe.place(relx=0.82, rely=0.2, relwidth=0.15, relheight=0.4)




    # ------ VARIABLE DECLARATION---------
    afm1 = StringVar()
    DOY = tk.StringVar()
    NAME = tk.StringVar()
    PHONE = tk.StringVar()
    STREET = tk.StringVar()
    NUM = tk.StringVar()
    CITY = tk.StringVar()
    COUNTRY = tk.StringVar()
    # ----------------------LABELS AND ENTRIES FOR COMPANY---------------------------------





    afm = tk.Label(frame1, text='AFM', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=0, column=0, sticky='W', padx=5)
    afmentry = tk.Entry(frame1, textvariable=afm1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')

    afmentry.grid(row=0, column=1, sticky='W', padx=5)



    doy = tk.Label(frame1, text='DOY', fg='red', font=('arial', 12, 'bold'), bd=7)
    doy.grid(row=1, column=0, sticky='W', padx=5)
    doyentry = tk.Entry(frame1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    doyentry.grid(row=1, column=1, sticky='W', padx=5)


    name = tk.Label(frame1, text='NAME', fg='red', font=('arial', 12, 'bold'), bd=7)
    name.grid(row=2, column=0, sticky='W', padx=5)
    nameentry = tk.Entry(frame1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=NAME)
    nameentry.grid(row=2, column=1, sticky='W', padx=5)

    phone = tk.Label(frame1, text='PHONE', fg='red',font=('arial', 12,'bold'), bd=7)
    phone.grid(row= 3, column=0, sticky='W', padx=5)
    phoneentry = tk.Entry(frame1, width=44,font=('arial', 12,'bold'), bd=5, justify='left', textvariable=PHONE)
    phoneentry.grid(row=3, column=1, sticky='W', padx=5)

    street = tk.Label(frame1, text='STREET', fg='red', font=('arial', 12, 'bold'), bd=7)
    street.grid(row=4, column=0, sticky='W', padx=5)
    streetentry = tk.Entry(frame1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=STREET)
    streetentry.grid(row=4, column=1, sticky='W', padx=5)

    num = tk.Label(frame1, text='NUMBER', fg='red', font=('arial', 12, 'bold'), bd=7)
    num.grid(row=5, column=0, sticky='W', padx=5)
    numentry = tk.Entry(frame1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=NUM)
    numentry.grid(row=5, column=1, sticky='W', padx=5)

    phone = tk.Label(frame1, text='CITY', fg='red', font=('arial', 12, 'bold'), bd=7)
    phone.grid(row=6, column=0, sticky='W', padx=5)
    cityentry = tk.Entry(frame1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=CITY)
    cityentry.grid(row=6, column=1, sticky='W', padx=5)

    country = tk.Label(frame1, text='COUNTRY', fg='red', font=('arial', 12, 'bold'), bd=7)
    country.grid(row=7, column=0, sticky='W', padx=5)
    countryentry = tk.Entry(frame1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=COUNTRY)
    countryentry.grid(row=7, column=1, sticky='W', padx=5)

    # -----------CONTENT OF TREEVIEW-------------
    def Traineeinfo(ev):
        viewinfo = records.focus()
        data = records.item(viewinfo)

        row = data['values']


        afmentry.config(state=NORMAL)
        afmentry.delete(0,END)
        afmentry.insert(END,row[0])
        afmentry.config(state=DISABLED)

        doyentry.delete(0, END)
        doyentry.config(state=NORMAL)
        doyentry.delete(0,END)
        doyentry.insert(END, row[1])
        doyentry.config(state=DISABLED)

        nameentry.config(state= NORMAL)
        nameentry.delete(0, END)
        nameentry.insert(END, row[2])
        nameentry.config(state=DISABLED)

        phoneentry.delete(0, END)
        phoneentry.insert(END, row[3])
        streetentry.delete(0, END)
        streetentry.insert(END, row[4])
        numentry.delete(0, END)
        numentry.insert(END, row[5])
        cityentry.delete(0, END)
        cityentry.insert(END, row[6])
        countryentry.delete(0, END)
        countryentry.insert(END, row[7])


    # ------------------CREATION OF TREEVIEW----------------------------------

    scrollbar = Scrollbar(bottomframe, orient=VERTICAL)
    records = ttk.Treeview(bottomframe, yscrollcommand = scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns']=( 'AFM','DOY', 'NAME', 'PHONE', 'STREET', 'NUM', 'CITY', 'COUNTRY')

    records.column('AFM', width=60)
    records.column('DOY', width=60)
    records.column('NAME', width=60)
    records.column('PHONE', width=60)
    records.column('STREET', width=60)
    records.column('NUM', width=60)
    records.column('CITY', width=60)
    records.column('COUNTRY', width=60)

    records['show'] = 'headings'

    records.heading('AFM', text='AFM')
    records.heading('DOY', text='DOY')
    records.heading('NAME', text='Name')
    records.heading('PHONE', text='Phone')
    records.heading('STREET', text='Street')
    records.heading('NUM', text='Number')
    records.heading('CITY', text='City')
    records.heading('COUNTRY', text='Country')
    records.pack(fill=BOTH, expand=1)
    records.bind('<ButtonRelease-1>', Traineeinfo)


    # --------------DISPLAY-UPDATE-EXIT--------------------------
    def Display():

        db = mysql.connector.connect(host='127.0.0.1',  user='root', port=3306, password='123456', database='staff')
        cursor = db.cursor()
        cursor.execute('SELECT * FROM company')
        res = cursor.fetchall()
        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:

                records.insert('',END,values = x)
        db.commit()
        db.close()

    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        cursor.execute('update staff.company set phone=%s,street=%s,num=%s,city=%s,country=%s where AFM=%s and DOY=%s and name=%s',(



        phoneentry.get(),
        streetentry.get(),
        numentry.get(),
        cityentry.get(),
        countryentry.get(),
        afmentry.get(),
        doyentry.get(),
        nameentry.get()
        ))

        db.commit()
        db.close()
        tk.messagebox.showinfo('RECORD FORM ENTRY ', 'RECORD UPDATED SUCCESSFULLY!',parent=company1)

    def Back():

        company1.destroy()



    # --------------------BUTTONS---------------------
    update = tk.Button(rightframe,text='UPDATE', fg='blue', font=('arial', 12, 'bold'), command=Update)
    update.place(relx=0, rely=0, relwidth=1, relheight=0.33)
    exit = tk.Button(rightframe, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
    exit.place(relx=0, rely=0.35, relwidth=1, relheight=0.33)
    display = tk.Button( rightframe,text='DISPLAY DATA', fg='blue', font=('arial', 12, 'bold'), command=Display)
    display.place(relx=0, rely=0.7, relwidth=1., relheight=0.33)


    #company1.mainloop()

# --------------PERSONAL INFO-----------------------------
def personal():
    personalroot = tk.Toplevel()
    personalroot.title('ACCOUNT INFORMATION')
    canvas = tk.Canvas(personalroot, height=400,width=800, bg='red')
    canvas.pack()
    mainframe = tk.Frame(personalroot, bg='white')
    mainframe.place(relx=0.5, rely=0, relwidth=0.6, relheight=0.8, anchor='n')
    rightframe=tk.Frame(personalroot, bg='white')
    rightframe.place(relx=0.8, rely=0.2, relwidth=0.2, relheight=0.4)

    # -----------LABELS AND ENTRIES----------------
    emailstr = StringVar()
    passwordstr = StringVar()
    newpasswordstr = StringVar()
    email = tk.Label(mainframe, text='EMAIL', fg='red', font=('arial', 12, 'bold'), bd=7)
    email.grid(row=0, column=0, sticky='W', padx=5)
    emailentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=emailstr)
    emailentry.grid(row=0, column=1, sticky='W', padx=5)

    passwd = tk.Label(mainframe, text='NEW PASSWORD', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd.grid(row=2, column=0, sticky='W', padx=5)
    passwdentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left',
                           textvariable=passwordstr)
    passwdentry.grid(row=2, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(mainframe, text='RETYPE NEW PASSWORD', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=4, column=0, sticky='W', padx=5)
    newpasswdentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left',
                              textvariable=newpasswordstr)
    newpasswdentry.grid(row=4, column=1, sticky='W', padx=5)

# -------------BUTTONS----------------------------------




    def Display():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        strh = "'"
        cursor.execute("SELECT email FROM userw where username='"  + USERNAME.get() + strh
                       )
        data= cursor.fetchall()
        '''cursor.execute('SELECT password FROM userw where username='+ entry_email.get(),)
        passworddata = cursor.fetchall()'''

        emailentry.delete(0,END)
        emailentry.insert(END,data)
        '''passwdentry.delete(0,END)
        passwdentry.insert(END, passworddata)'''
        db.commit()
        db.close()
    Display()

    def Back():
        personalroot.destroy()

    backbut = tk.Button(rightframe, text='BACK', fg='red', font=('arial', 12, 'bold'), command=Back)
    backbut.place(relx=0, rely=0.5, relwidth=1, relheight=0.5)

    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        strh= '"'
        if (newpasswdentry.get() == passwdentry.get() and newpasswdentry.get()==''):
            newpasswdentry.delete(0, END)
            passwdentry.delete(0, END)

            tk.messagebox.showerror("PASSWORD  FAILURE", "PASSWORD CANT BE BLANK! PLEASE INSERT A VALID PASSWORD ", parent=personalroot)

        elif (newpasswdentry.get() == passwdentry.get()):
            cursor.execute('update staff.userw set email=%s, password=%s where username=%s'  ,(

            emailentry.get(),
            passwdentry.get(),
            USERNAME.get()
            #newpasswdentry.get()
            ))
            tk.messagebox.showinfo("PASSWORD/EMAIL UPDATE","PASSWORD/EMAIL UPDATED SUCCESSFULLY", parent=personalroot)
        else:
            newpasswdentry.delete(0,END)
            passwdentry.delete(0,END)

            tk.messagebox.showerror("PASSWORD CONFIRMATION FAILURE", "THE TWO FIELDS MUST MATCH", parent=personalroot)
        db.commit()
        db.close()
    updatebut = tk.Button(rightframe, text='UPDATE INFO', fg='red', font=('arial', 12, 'bold'), command=Update)
    updatebut.place(relx=0, rely=0, relwidth=1, relheight=0.49)


    #personalroot.mainloop()

    # --------------------EMPLOYEE-------------------
def Employee():
    employee1 = tk.Toplevel()
    employee1.title('EMPLOYEE INFORMATION')
    canvas = tk.Canvas(employee1, width=800, height=650, bg='blue')
    canvas.pack()
    mainframe = tk.Frame(employee1, bg='white')
    mainframe.place(relx=0, rely=0, relwidth=0.8, relheight=0.5)
    bottomframe = tk.Frame(employee1, bg='white')
    bottomframe.place(relx=0, rely=0.51, relwidth=1, relheight=0.49)

    rightframe = tk.Frame(employee1, bg='white')
    rightframe.place(relx=0.81, rely=0, relwidth=0.2, relheight=0.5)



    # ------ VARIABLE DECLARATION---------
    AFM = StringVar()
    DOY = StringVar()
    NAME = StringVar()
    PHONE = StringVar()
    STREET = StringVar()
    POSITION = StringVar()
    GRADE = StringVar()
    EVFIRST = StringVar()
    EVLAST = StringVar()

    # -----------DOUBLE CLICK EVENT-------------
    def Treeinfo(ev):
        viewinfo = records.focus()
        Datadisplay = records.item(viewinfo)
        row = Datadisplay['values']
        
        firstnameentry.config(state=NORMAL)
        firstnameentry.delete(0,END)
        firstnameentry.insert(END,row[0])
        firstnameentry.config(state=DISABLED)

        lastentry.config(state=NORMAL)
        lastentry.delete(0,END)
        lastentry.insert(END,row[1])
        lastentry.config(state=DISABLED)

        usernameentry.config(state=NORMAL)
        usernameentry.delete(0, END)
        usernameentry.insert(END, row[2])
        usernameentry.config(state=DISABLED)

        bioentry.config(state=NORMAL)
        bioentry.delete(0, END)
        bioentry.insert(END, row[3])
        bioentry.config(state=DISABLED)

        statisticsentry.delete(0,END)
        statisticsentry.insert(END,row[4])
        certificatesentry.delete(0,END)
        certificatesentry.insert(END,row[5])
        awardsentry.delete(0,END)
        awardsentry.insert(END,row[6])

    firstname = tk.Label(mainframe, text='FirstName', fg='red', font=('arial', 12, 'bold'), bd=7)
    firstname.grid(row=0, column=0, sticky='W', padx=5)
    firstnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left', textvariable=AFM)
    firstnameentry.grid(row=0, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(mainframe, text='LastName', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=1, column=0, sticky='W', padx=5)
    lastentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    lastentry.grid(row=1, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(mainframe, text='Username', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=2, column=0, sticky='W', padx=5)
    usernameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    usernameentry.grid(row=2, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(mainframe, text='Bio', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=3, column=0, sticky='W', padx=5)
    bioentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    bioentry.grid(row=3, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(mainframe, text='Statistics', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=4, column=0, sticky='W', padx=5)
    statisticsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    statisticsentry.grid(row=4, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(mainframe, text='Certificates', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=5, column=0, sticky='W', padx=5)
    certificatesentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    certificatesentry.grid(row=5, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(mainframe, text='Awards', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=6, column=0, sticky='W', padx=5)
    awardsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    awardsentry.grid(row=6, column=1, sticky='W', padx=5)





    # ---------TREEVIEW---------

    scrollbar = Scrollbar(bottomframe, orient=VERTICAL)
    records = ttk.Treeview(bottomframe, yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns'] = ('AFM','DOY', 'NUM', 'CITY' ,'NAME', 'PHONE', 'STREET')

    records.column('AFM', width=50)
    records.column('DOY', width=50)
    records.column('NUM', width=50)
    records.column('CITY', width=50)
    records.column('NAME', width=50)
    records.column('PHONE', width=50)
    records.column('STREET', width=50)



    records['show']='headings'

    records.heading('AFM', text='Employees FirstName')
    records.heading('DOY', text='Employees LastName')
    records.heading('NUM', text='Username')
    records.heading('CITY', text='Bio')
    records.heading('NAME', text='Statistics')
    records.heading('PHONE', text='Certificates')
    records.heading('STREET', text='Awards')



    records.pack(fill=BOTH)



    records.bind('<ButtonRelease-1>', Treeinfo)

    def Display():
        db = mysql.connector.connect(host='127.0.0.1', port='3306', user='root', password='123456', database='staff')
        cursor = db.cursor()
        cursor.execute('SELECT name,sumname,employee.username,bio,sustatikes,certificates,awards FROM employee inner join userw on userw.username=employee.username ')
        res = cursor.fetchall()
        #print(res)

        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                records.insert('', END, values=x)

        db.commit()
        db.close()

    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        cursor.execute('update staff.employee set sustatikes=%s,certificates=%s,awards=%s  where employee.username=%s', (


            statisticsentry.get(),
            certificatesentry.get(),
            awardsentry.get(),
            usernameentry.get()
        ))

        db.commit()
        db.close()
        tk.messagebox.showinfo('RECORD FORM ENTRY ', 'RECORD UPDATED SUCCESSFULLY!', parent=employee1)



    def Back():
        employee1.destroy()

        # --------BUTTONS-----------

    displaybut = tk.Button(rightframe, text='DISPLAY', fg='red', font=('arial', 12, 'bold'), command=Display)
    displaybut.place(relx=0, rely=0, relwidth=1, relheight=0.33)

    updatebutt = tk.Button(rightframe, text='UPDATE INFO', fg='red', font=('arial', 12, 'bold'), command=Update)
    updatebutt.place(relx=0, rely=0.34, relwidth=1, relheight=0.33)

    searchbutt = tk.Button(rightframe, text='BACK', fg='red', font=('arial', 12, 'bold'), command=Back)
    searchbutt.place(relx=0, rely=0.67, relwidth=1, relheight=.33)

# --------------JOB SALARY/EVALUATION WINDOW-------------------
def Job():
    jobroot = tk.Toplevel()
    jobroot.title("JOB SALARY/EVALUATION")
    canvas = tk.Canvas(jobroot, bg='red', width=800, height=600)
    canvas.pack()
    entriesframe1 = tk.Frame(jobroot, bg='white')
    entriesframe1.place(relx=0, rely=0, relwidth=0.79, relheight=0.5)
    treeframe = tk.Frame(jobroot, bg='red')
    treeframe.place(relx=0, rely=0.51, relwidth=1, relheight=0.49)
    rightframe = tk.Frame(jobroot, bg = 'white')
    rightframe.place(relx=0.8, rely=0, relwidth=0.2, relheight=0.5)
    # ---------ENTRIES AND LABELS--------------

    firstname = tk.Label(entriesframe1, text='POSITION', fg='red', font=('arial', 12, 'bold'), bd=7)
    firstname.grid(row=0, column=0, sticky='W', padx=5)
    positionentry = tk.Entry(entriesframe1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    positionentry.grid(row=0, column=1, sticky='W', padx=5)

    firstname = tk.Label(entriesframe1, text='SALARY', fg='red', font=('arial', 12, 'bold'), bd=7)
    firstname.grid(row=1, column=0, sticky='W', padx=5)
    salaryentry = tk.Entry(entriesframe1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    salaryentry.grid(row=1, column=1, sticky='W', padx=5)

    # ---------------DISPLAY AND UPDATE FUNCTIONS---------------------
    def Display():
        db = mysql.connector.connect(host='127.0.0.1', port='3306', user='root', password='123456', database='staff')
        cursor = db.cursor()
        cursor.execute('SELECT position,salary FROM job')
        res = cursor.fetchall()


        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                records.insert('', END, values=x)

        db.commit()
        db.close()

    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        if salaryentry.get()=='':
            tk.messagebox.showerror("SALARY ERROR","SALARY CANT BE NULL!"
                                                   " PLEASE INSERT A VALID SALARY", parent=jobroot)
        try:
            float(salaryentry.get())
            cursor.execute('update staff.job set salary=%s where position=%s',(


            salaryentry.get(),
            positionentry.get()
            ))
            tk.messagebox.showinfo('RECORD FORM ENTRY ', 'SALARY UPDATED SUCCESSFULLY!', parent=jobroot)
        except:
            tk.messagebox.showerror("SALARY ERROR", "SALARY ENTRY MUST ONLY CONTAIN NUMBERS!"
                                                    " PLEASE ENTER A VALID SALARY",parent=jobroot)



        db.commit()
        db.close()


    # ---------BUTTONS---------------
    salarybut = tk.Button(rightframe,  text='CHANGE SALARY', fg='red', font=('arial', 12, 'bold'), command=Update)
    salarybut.place(relx=0, rely=0, relwidth=1, relheight=0.33)

    displaybut = tk.Button(rightframe, text='DISPLAY DATA', fg='red', font=('arial', 12, 'bold'), command=Display)
    displaybut.place(relx=0, rely=0.34, relwidth=1, relheight=0.33)

    # -------------TreeView------------------
    scrollbar = Scrollbar(treeframe, orient=VERTICAL)
    records = ttk.Treeview(treeframe, yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns'] = ('AFM', 'DOY')

    records.column('AFM', width=50)
    records.column('DOY', width=50)


    records['show'] = 'headings'

    records.heading('AFM', text='POSITION')
    records.heading('DOY', text='SALARY')


    records.pack(fill=BOTH)
    def Treeinfo(ev):
        viewinfo = records.focus()
        Datadisplay = records.item(viewinfo)
        row = Datadisplay['values']

        positionentry.config(state= NORMAL)
        positionentry.delete(0,END)
        positionentry.insert(END,row[0])
        positionentry.config(state=DISABLED)

        salaryentry.delete(0,END)
        salaryentry.insert(END,row[1])

    records.bind('<ButtonRelease-1>', Treeinfo)

def Searchgui():
    searchroot = tk.Toplevel()
    searchroot.title("SEARCH EMPLOYEE")
    canvas = tk.Canvas(searchroot, bg='red', width=800, height=600)
    canvas.pack()
    entriesframe1 = tk.Frame(searchroot, bg='white')
    entriesframe1.place(relx=0, rely=0, relwidth=0.79, relheight=0.5)
    treeframe = tk.Frame(searchroot, bg='red')
    treeframe.place(relx=0, rely=0.51, relwidth=1, relheight=0.49)
    rightframe = tk.Frame(searchroot, bg='white')
    rightframe.place(relx=0.8, rely=0, relwidth=0.2, relheight=0.5)

    firstname = tk.Label(entriesframe1, text='FirstName', fg='red', font=('arial', 12, 'bold'), bd=7)
    firstname.grid(row=0, column=0, sticky='W', padx=5)
    firstnameentry = tk.Entry(entriesframe1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    firstnameentry.grid(row=0, column=1, sticky='W', padx=5)

    newpasswd = tk.Label(entriesframe1, text='LastName', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd.grid(row=1, column=0, sticky='W', padx=5)
    lastentry = tk.Entry(entriesframe1, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    lastentry.grid(row=1, column=1, sticky='W', padx=5)




    def Treeinfo(ev):
        viewinfo = records.focus()
        Datadisplay = records.item(viewinfo)
        row = Datadisplay['values']
        firstnameentry.delete(0, END)
        firstnameentry.insert(END, row[0])
        lastentry.delete(0, END)
        lastentry.insert(END, row[1])



    # -------------TreeView------------------
    scrollbar = Scrollbar(treeframe, orient=VERTICAL)
    records = ttk.Treeview(treeframe, yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns'] = ('AFM', 'DOY')

    records.column('AFM', width=50)
    records.column('DOY', width=50)

    records['show'] = 'headings'

    records.heading('AFM', text='FIRSTNAME')
    records.heading('DOY', text='LASTNAME')

    records.pack(fill=BOTH, expand=1)
    records.bind('<ButtonRelease-1>', Treeinfo)

    def Display():
        db = mysql.connector.connect(host='127.0.0.1', port='3306', user='root', password='123456', database='staff')
        cursor = db.cursor()
        cursor.execute('SELECT name,sumname FROM userw inner join employee on employee.username=userw.username where employee.username=userw.username')
        res = cursor.fetchall()

        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                records.insert('', END, values=x)

        db.commit()
        db.close()

    Display()


    def Search():
        db = mysql.connector.connect(host='127.0.0.1', port='3306', user='root', password='123456', database='staff')
        cursor = db.cursor()


        cursor.execute('call getEvaluation(%s,%s )' ,(firstnameentry.get(),
                                                      lastentry.get())
         )
        res = cursor.fetchall()
        if res==[]:
            tk.messagebox.showinfo("SEARCH RESULT","NO SUCH RECORD FOUND", parent=searchroot)
        print(res)

    salarybut = tk.Button(rightframe, text='SEARCH FOR EMPLOYEE', fg='red', font=('arial', 12, 'bold'), command=Search)
    salarybut.place(relx=0, rely=0, relwidth=1, relheight=0.33)

    def Back():
        searchroot.destroy()

    displaybut = tk.Button(rightframe, text='BACK', fg='red', font=('arial', 12, 'bold'), command=Back)
    displaybut.place(relx=0, rely=0.34, relwidth=1, relheight=0.33)


#managerpage()
# =================================EVALUATOR================================



def evaluatorpage():
    roothaha.destroy()
    root = tk.Tk()
    root.title('EVALUATOR ACCOUNT')

    canvas = tk.Canvas(root, bg='red', height=600, width=1067)
    canvas.pack()
    label = tk.Label(root, text='EVALUATOR ACCOUNT', fg='red', font=100)
    label.place(relx=0.42, rely=0.1)

    comp_button = tk.Button(root, text='JOBS', fg='red', command=Jobsevs)
    comp_button.place(relx=0.1, rely=0.35, relwidth=0.2, relheight=0.1)

    personal_button = tk.Button(root, text='PERSONAL INFO', fg='red', command=Personalinfo )
    personal_button.place(relx=0.4, rely=0.35, relwidth=0.2, relheight=0.1)

    employee_button = tk.Button(root, text='INSERT A JOB', fg='red', command=InsertJob)
    employee_button.place(relx=0.7, rely=0.35, relwidth=0.2, relheight=0.1)

    evaluation_button = tk.Button(root, text='VIEW/EDIT MY JOBS', fg='red', command=MyJobs)
    evaluation_button.place(relx=0.1, rely=0.6, relwidth=0.2, relheight=0.1)

    def Logout():
        Exit = tk.messagebox.askyesno("LOGOUT",'DO YOU REALLY WANT TO LOGOUT?',parent=root)
        if Exit > 0:
            root.destroy()
            return

    exitbutton = tk.Button(root,text='LOGOUT', fg='red', command=Logout)
    exitbutton.place(relx=0.4,rely=0.6, relwidth=0.2,relheight=0.1)

    root.mainloop()


def Personalinfo():

    personalroot = tk.Toplevel()
    personalroot.title('USER INFORMATION')
    canvas = tk.Canvas(personalroot, height=400, width=600, bg='red')
    canvas.pack()
    mainframe = tk.Frame(personalroot, bg='white')
    mainframe.place(relx=0, rely=0, relwidth=1, relheight=1)


    # ----------DISPLAY EVALUATORS INFO AUTOMATICALLY-----------------------

    def Display():
        db = mysql.connector.connect(host='localhost', port=3306, user='root', password='123456',
                                     database='staff')

        cursor1 = db.cursor()
        strh = '"'
        cursor1.execute('SELECT * FROM staff.userw where username="' + USERNAME.get() + strh)  # -----PWS KANE TAUTOPOIHSH ME TO USERNAME EDW?????


        res1 = cursor1.fetchall()
        for x in res1:

            usernameentry.config(state = NORMAL)
            usernameentry.insert(END, x[0])
            usernameentry.config(state = DISABLED)

            passwordentry.insert(END, x[1])
            firstnameentry.insert(END, x[2])
            lastnameentry.insert(END, x[3])
            regentry.insert(END, x[4])
            emailentry.insert(END, x[5])

        cursor1.execute('select exp_years,FIM from staff.evaluator where username="' + USERNAME.get() + strh)
        res2 = cursor1.fetchall()

        for y in res2:
            expyearsentry.insert(END, y[0])
            firmentry.insert(END, y[1])

        db.commit()
        db.close()

    # ------------------ ENTRIES AND LABELS---------------------------------------------------------

    afm = tk.Label(mainframe, text='Username', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=0, column=0, sticky='W', padx=5)
    usernameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    usernameentry.grid(row=0, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Password', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=1, column=0, sticky='W', padx=5)
    passwordentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    passwordentry.grid(row=1, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='FirstName', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=2, column=0, sticky='W', padx=5)
    firstnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    firstnameentry.grid(row=2, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='LastName', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=3, column=0, sticky='W', padx=5)
    lastnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    lastnameentry.grid(row=3, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Register Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=4, column=0, sticky='W', padx=5)
    regentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    regentry.grid(row=4, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Email', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=5, column=0, sticky='W', padx=5)
    emailentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    emailentry.grid(row=5, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Years of Experience', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=6, column=0, sticky='W', padx=5)
    expyearsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    expyearsentry.grid(row=6, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Firm', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=7, column=0, sticky='W', padx=5)
    firmentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    firmentry.grid(row=7, column=1, sticky='W', padx=5)

    Display()

    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        cursor.execute('update staff.userw set password=%s,name=%s,sumname=%s,reg_date=%s,email=%s where username=%s',(


        passwordentry.get(),
        firstnameentry.get(),
        lastnameentry.get(),
        regentry.get(),
        emailentry.get(),
        usernameentry.get()
        ))

        cursor.execute('update staff.evaluator set exp_years=%s,FIM=%s where username=%s',(
        expyearsentry.get(),
        firmentry.get(),
        usernameentry.get()
        ))

        db.commit()
        db.close()
        tk.messagebox.showinfo('RECORD FORM ENTRY ', 'RECORD UPDATED SUCCESSFULLY!',parent=personalroot)

    # ------------BUTTONS FOR EVALUATORS INFO---------------------------------
    updatebutt = tk.Button(mainframe, text='UPDATE', fg='blue', font=('arial', 12, 'bold'), command=Update)
    updatebutt.place(relx=0.1, rely=0.75, relwidth=0.25, relheight=0.25)

    def Back():
        personalroot.destroy()




    backbutt = tk.Button(mainframe, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
    backbutt.place(relx=0.6, rely=0.75, relwidth=0.25, relheight=0.25)

    #personalroot.mainloop()

def Jobsevs():
    jobsroot = tk.Toplevel()
    jobsroot.title("JOBS")
    canvas = tk.Canvas(jobsroot, bg='white', width=800, height=600)
    canvas.pack()
    mainframe = tk.Frame(jobsroot, bg='red')
    mainframe.place(relx=0, rely=0, relwidth=0.8, relheight=0.55)
    bottomframe = tk.Frame(jobsroot, bg='yellow')
    bottomframe.place(relx=0, rely=0.57, relwidth=1, relheight=0.43)

    def Treeinfo(ev):
        viewinfo = records.focus()
        Datadisplay = records.item(viewinfo)
        row = Datadisplay['values']

        jobidentry.config(state = NORMAL)
        jobidentry.delete(0,END)
        jobidentry.insert(END,row[0])
        jobidentry.config(state = DISABLED)

        startdateentry.delete(0,END)
        startdateentry.insert(END,row[1])
        salaryentry.delete(0,END)
        salaryentry.insert(END,row[2])
        positionentry.delete(0,END)
        positionentry.insert(END,row[3])
        edraentry.delete(0,END)
        edraentry.insert(END,row[4])
        announcedateentry.delete(0, END)
        announcedateentry.insert(END, row[5])

        submissiondateentry.config(state = NORMAL)
        submissiondateentry.delete(0, END)
        submissiondateentry.insert(END, row[6])
        submissiondateentry.config(state = DISABLED)

        evaluatorentry.config(state = NORMAL)
        evaluatorentry.delete(0, END)
        evaluatorentry.insert(END, row[7])
        evaluatorentry.config(state = DISABLED)



    # ------------------CREATION OF TREEVIEW----------------------------------

    scrollbar = Scrollbar(bottomframe, orient=VERTICAL)
    records = ttk.Treeview(bottomframe, yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns'] = ('AFM', 'DOY', 'NAME', 'PHONE', 'STREET', 'NUM', 'CITY','kappa')

    records.column('AFM', width=60)
    records.column('DOY', width=60)
    records.column('NAME', width=60)
    records.column('PHONE', width=60)
    records.column('STREET', width=60)
    records.column('NUM', width=60)
    records.column('CITY', width=60)
    records.column('kappa', width=60)


    records['show'] = 'headings'

    records.heading('AFM', text='JOB ID')
    records.heading('DOY', text='START DATE')
    records.heading('NAME', text='SALARY')
    records.heading('PHONE', text='POSITION')
    records.heading('STREET', text='EDRA')
    records.heading('NUM', text='ANNOUNCE DATE')
    records.heading('CITY', text='SUBMISSION DATE')
    records.heading('kappa', text='EVALUATOR')

    records.pack(fill=BOTH, expand=1)
    records.bind('<ButtonRelease-1>', Treeinfo)

    # -------------------ENTRIES AND LABELS--------------------------------

    afm = tk.Label(mainframe, text='Job ID', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=0, column=0, sticky='W', padx=5)
    jobidentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    jobidentry.grid(row=0, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Start Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=1, column=0, sticky='W', padx=5)
    startdateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    startdateentry.grid(row=1, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Salary', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=2, column=0, sticky='W', padx=5)
    salaryentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    salaryentry.grid(row=2, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Position', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=3, column=0, sticky='W', padx=5)
    positionentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    positionentry.grid(row=3, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Edra', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=4, column=0, sticky='W', padx=5)
    edraentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    edraentry.grid(row=4, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Announce Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=5, column=0, sticky='W', padx=5)
    announcedateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    announcedateentry.grid(row=5, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Submission Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=6, column=0, sticky='W', padx=5)
    submissiondateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    submissiondateentry.grid(row=6, column=1, sticky='W', padx=5)
    afm = tk.Label(mainframe, text='Evaluator', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=7, column=0, sticky='W', padx=5)
    evaluatorentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    evaluatorentry.grid(row=7, column=1, sticky='W', padx=5)

    # -------------------DISPLAY-UPDATE--------------------------
    def Display():
        db = mysql.connector.connect(host='127.0.0.1', port='3306', user='root', password='123456', database='staff')
        cursor = db.cursor()
        cursor.execute(
            'SELECT id,start_date,salary,position,edra,announce_date,submission_date,evaluator FROM staff.job  ',

            )
        res = cursor.fetchall()


        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                records.insert('', END, values=x)

        db.commit()
        db.close()
    Display()
    # STO UPDATE PREPEI NA KANW AUTHENTICATION TOU EVALUATOR STO JOB ME TO USERNAME STO USERW
    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        try:
            cursor.execute('update staff.job set id=%s,start_date=%s,salary=%s,position=%s,edra=%s,announce_date=%s,submission_date=%s where evaluator=%s', (

                jobidentry.get(),
                startdateentry.get(),
                salaryentry.get(),
                positionentry.get(),
                edraentry.get(),
                announcedateentry.get(),
                submissiondateentry.get(),
                USERNAME.get()



            ))



            db.commit()
            db.close()
            tk.messagebox.showinfo('RECORD FORM ENTRY ', 'RECORD UPDATED SUCCESSFULLY!', parent=jobsroot)
        except:
            tk.messagebox.showerror("UPDATE ERROR","NOTE THAT YOU CAN ONLY UPDATE THE JOBS THAT ARE EVALUATED BY YOU", parent=jobsroot)
    updatebutt = tk.Button(jobsroot, text='UPDATE', fg='blue', font=('arial', 12, 'bold'), command=Update)
    updatebutt.place(relx=0.8, rely=0, relwidth=0.19, relheight=0.2)

    def Back():
        jobsroot.destroy()

    backbutt = tk.Button(jobsroot, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
    backbutt.place(relx=0.8, rely=0.21, relwidth=0.19, relheight=0.2)

def InsertJob():
    insertjobsroot = tk.Toplevel()
    insertjobsroot.title("JOBS")
    canvas = tk.Canvas(insertjobsroot, bg='white', width=800, height=600)
    canvas.pack()
    mainframe = tk.Frame(insertjobsroot, bg='red')
    mainframe.place(relx=0, rely=0, relwidth=1, relheight=1)

    afm = tk.Label(mainframe, text='Job ID', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=0, column=0, sticky='W', padx=5)
    jobidentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    jobidentry.grid(row=0, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Start Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=1, column=0, sticky='W', padx=5)
    startdateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    startdateentry.grid(row=1, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Salary', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=2, column=0, sticky='W', padx=5)
    salaryentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    salaryentry.grid(row=2, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Position', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=3, column=0, sticky='W', padx=5)
    positionentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    positionentry.grid(row=3, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Edra', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=4, column=0, sticky='W', padx=5)
    edraentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    edraentry.grid(row=4, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Evaluator', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=5, column=0, sticky='W', padx=5)
    evaluatorentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    evaluatorentry.grid(row=5, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Announce Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=6, column=0, sticky='W', padx=5)
    announcedateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    announcedateentry.grid(row=6, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Submission Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=7, column=0, sticky='W', padx=5)
    submissiondateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    submissiondateentry.grid(row=7, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Title', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=8, column=0, sticky='W', padx=5)
    titleentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    titleentry.grid(row=8, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Description', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=9, column=0, sticky='W', padx=5)
    descriptionentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    descriptionentry.grid(row=9, column=1, sticky='W', padx=5)

    '''afm = tk.Label(mainframe, text='Belongs To', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=10, column=0, sticky='W', padx=5)
    belongstoentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    belongstoentry.grid(row=10, column=1, sticky='W', padx=5)'''

    def Insert():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        #cursor1=db.cursor()





        cursor.execute('insert into staff.job(id,start_date,salary,position,edra,evaluator,announce_date,submission_date) values (%s,%s,%s,%s,%s,%s,%s,%s)  '




                       ,(
            jobidentry.get(),
            startdateentry.get(),
            salaryentry.get(),
            positionentry.get(),
            edraentry.get(),
            evaluatorentry.get(),
            announcedateentry.get(),
            datetime.datetime.now(),

        ))

        cursor.execute(

            'insert into staff.antikeim(title,descr,belong_to) values(%s,%s,%s)'
            , (
                titleentry.get(),
                descriptionentry.get(),
                titleentry.get()
            ))
        cursor.execute('insert into needs(job_id,antikeim_title) values(%s,%s)',(
            jobidentry.get(),
            titleentry.get()
        ))

        tk.messagebox.showinfo("JOB CREATION","JOB CREATED SUCCESSFULLY", parent=insertjobsroot)
        db.commit()
        db.close()

    def Back():
        insertjobsroot.destroy()

    def Reset():
        jobidentry.delete(0, END)
        startdateentry.delete(0, END)
        salaryentry.delete(0, END)
        positionentry.delete(0, END)
        edraentry.delete(0, END)
        evaluatorentry.delete(0, END)
        announcedateentry.delete(0, END)
        submissiondateentry.delete(0, END)
        titleentry.delete(0, END)
        descriptionentry.delete(0, END)


    insertjobbutt = tk.Button(mainframe, text='INSERT NEW JOB', fg='blue', font=('arial', 12, 'bold'), command=Insert)
    insertjobbutt.place(relx=0.05, rely=0.7, relwidth=0.25, relheight=0.2)

    insertjobbutt = tk.Button(mainframe, text='RESET', fg='blue', font=('arial', 12, 'bold'), command=Reset)
    insertjobbutt.place(relx=0.31, rely=0.7, relwidth=0.25, relheight=0.2)

    insertjobbutt = tk.Button(mainframe, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
    insertjobbutt.place(relx=0.58, rely=0.7, relwidth=0.25, relheight=0.2)

def MyJobs():
    jobsroot = tk.Toplevel()
    jobsroot.title("JOBS")
    canvas = tk.Canvas(jobsroot, bg='white', width=800, height=600)
    canvas.pack()
    mainframe = tk.Frame(jobsroot, bg='red')
    mainframe.place(relx=0, rely=0, relwidth=0.8, relheight=0.55)
    bottomframe = tk.Frame(jobsroot, bg='yellow')
    bottomframe.place(relx=0, rely=0.57, relwidth=1, relheight=0.43)

    def Treeinfo(ev):
        viewinfo = records.focus()
        Datadisplay = records.item(viewinfo)
        row = Datadisplay['values']

        jobidentry.config(state = NORMAL)
        jobidentry.delete(0, END)
        jobidentry.insert(END, row[0])
        jobidentry.config(state = DISABLED)

        startdateentry.delete(0, END)
        startdateentry.insert(END, row[1])
        salaryentry.delete(0, END)
        salaryentry.insert(END, row[2])
        positionentry.delete(0, END)
        positionentry.insert(END, row[3])
        edraentry.delete(0, END)
        edraentry.insert(END, row[4])
        announcedateentry.delete(0, END)
        announcedateentry.insert(END, row[5])

        submissiondateentry.config(state = NORMAL)
        submissiondateentry.delete(0, END)
        submissiondateentry.insert(END, row[6])
        submissiondateentry.config(state = DISABLED)

    # ------------------CREATION OF TREEVIEW----------------------------------

    scrollbar = Scrollbar(bottomframe, orient=VERTICAL)
    records = ttk.Treeview(bottomframe, yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns'] = ('AFM', 'DOY', 'NAME', 'PHONE', 'STREET', 'NUM', 'CITY')

    records.column('AFM', width=60)
    records.column('DOY', width=60)
    records.column('NAME', width=60)
    records.column('PHONE', width=60)
    records.column('STREET', width=60)
    records.column('NUM', width=60)
    records.column('CITY', width=60)

    records['show'] = 'headings'

    records.heading('AFM', text='JOB ID')
    records.heading('DOY', text='START DATE')
    records.heading('NAME', text='SALARY')
    records.heading('PHONE', text='POSITION')
    records.heading('STREET', text='EDRA')
    records.heading('NUM', text='ANNOUNCE DATE')
    records.heading('CITY', text='SUBMISSION DATE')

    records.pack(fill=BOTH, expand=1)
    records.bind('<ButtonRelease-1>', Treeinfo)

    # -------------------ENTRIES AND LABELS--------------------------------

    afm = tk.Label(mainframe, text='Job ID', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=0, column=0, sticky='W', padx=5)
    jobidentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    jobidentry.grid(row=0, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Start Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=1, column=0, sticky='W', padx=5)
    startdateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    startdateentry.grid(row=1, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Salary', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=2, column=0, sticky='W', padx=5)
    salaryentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    salaryentry.grid(row=2, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Position', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=3, column=0, sticky='W', padx=5)
    positionentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    positionentry.grid(row=3, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Edra', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=4, column=0, sticky='W', padx=5)
    edraentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    edraentry.grid(row=4, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Announce Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=5, column=0, sticky='W', padx=5)
    announcedateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    announcedateentry.grid(row=5, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Submission Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=6, column=0, sticky='W', padx=5)
    submissiondateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    submissiondateentry.grid(row=6, column=1, sticky='W', padx=5)

    # -------------------DISPLAY-UPDATE--------------------------
    def Display():
        db = mysql.connector.connect(host='127.0.0.1', port='3306', user='root', password='123456', database='staff')
        cursor = db.cursor()
        strh = '"'
        cursor.execute(
            'SELECT id,start_date,salary,position,edra,announce_date,submission_date FROM staff.job where evaluator="' + USERNAME.get() + strh

        )
        res = cursor.fetchall()

        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                records.insert('', END, values=x)

        db.commit()
        db.close()

    Display()

    # STO UPDATE PREPEI NA KANW AUTHENTICATION TOU EVALUATOR STO JOB ME TO USERNAME STO USERW
    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        cursor.execute(
            'update staff.job set start_date=%s,salary=%s,position=%s,edra=%s,announce_date=%s where id=%s and submission_date=%s',
            (


                startdateentry.get(),
                salaryentry.get(),
                positionentry.get(),
                edraentry.get(),
                announcedateentry.get(),
                jobidentry.get(),
                submissiondateentry.get()

            ))

        db.commit()
        db.close()
        tk.messagebox.showinfo('RECORD FORM ENTRY ', 'RECORD UPDATED SUCCESSFULLY!', parent=jobsroot)

    updatebutt = tk.Button(jobsroot, text='UPDATE', fg='blue', font=('arial', 12, 'bold'), command=Update)
    updatebutt.place(relx=0.8, rely=0, relwidth=0.19, relheight=0.2)

    def Back():
        jobsroot.destroy()

    backbutt = tk.Button(jobsroot, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
    backbutt.place(relx=0.8, rely=0.21, relwidth=0.19, relheight=0.2)

#evaluatorpage()
# =================================ADMIN================================














def adminmainpage():
    roothaha.destroy()
    root = tk.Tk()
    root.title("ADMIN PAGE")
    canvas = tk.Canvas(root, width=600, height=400)

    canvas.pack()
    frame = tk.Frame(root)
    frame.place(relx=0, rely=0, relwidth=1, relheight=1)

    # -------------CHECKBOX----------

    def usercheckbox():
        master = tk.Toplevel()
        master.title("USER CREATION")
        master.geometry('400x250')
        '''canvas = tk.Canvas(master, height=200, width=200)
        canvas.pack()
        frame = tk.Frame(master, height=100, width=200)
        frame.pack()'''

        # ------------CHECKBOX SELECTION-----------------
        def click_me():

            if var1.get() == 1 and var2.get() == 0 and var3.get() == 0:

                newemployee()
            elif var1.get() == 0 and var2.get() == 1 and var3.get() == 0:
                newmanager()
            elif var1.get() == 0 and var2.get() == 0 and var3.get() == 1:
                newevaluator()

            else:
                tk.messagebox.showerror("CHECKBOX ERROR", "PLEASE SELECT ONLY ONE OF THE GIVEN OPTIONS")

        def newevaluator():
            master.destroy()
            employeeroot = tk.Toplevel()
            employeeroot.title("EVALUATOR REGISTRATION")
            canvas = tk.Canvas(employeeroot, width=600, height=450)
            canvas.pack()
            mainframe = tk.Frame(employeeroot, bg='red')
            mainframe.place(relx=0, rely=0, relheight=1, relwidth=1)

            # --------------ENTRIES AND LABELS-------------------

            num = tk.Label(mainframe, text='Username', fg='red', font=('arial', 12, 'bold'), bd=7)
            num.grid(row=0, column=0, sticky='W', padx=5)
            userentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            userentry.grid(row=0, column=1, sticky='W', padx=5)

            nu2 = tk.Label(mainframe, text='Password', fg='red', font=('arial', 12, 'bold'), bd=7)
            nu2.grid(row=1, column=0, sticky='W', padx=5)
            passwdentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            passwdentry.grid(row=1, column=1, sticky='W', padx=5)

            num3 = tk.Label(mainframe, text='FirstName', fg='red', font=('arial', 12, 'bold'), bd=7)
            num3.grid(row=2, column=0, sticky='W', padx=5)
            firstnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            firstnameentry.grid(row=2, column=1, sticky='W', padx=5)

            num4 = tk.Label(mainframe, text='LastName', fg='red', font=('arial', 12, 'bold'), bd=7)
            num4.grid(row=3, column=0, sticky='W', padx=5)
            lastnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            lastnameentry.grid(row=3, column=1, sticky='W', padx=5)

            num6 = tk.Label(mainframe, text='Email', fg='red', font=('arial', 12, 'bold'), bd=7)
            num6.grid(row=4, column=0, sticky='W', padx=5)
            emailentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            emailentry.grid(row=4, column=1, sticky='W', padx=5)

            num7 = tk.Label(mainframe, text=' Years of Experience', fg='red', font=('arial', 12, 'bold'), bd=7)
            num7.grid(row=5, column=0, sticky='W', padx=5)
            expyearsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            expyearsentry.grid(row=5, column=1, sticky='W', padx=5)

            num8 = tk.Label(mainframe, text='Firm', fg='red', font=('arial', 12, 'bold'), bd=7)
            num8.grid(row=6, column=0, sticky='W', padx=5)
            firmentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            firmentry.grid(row=6, column=1, sticky='W', padx=5)

            def Adduserevaluator():
                db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
                cursor1 = db.cursor()

                try:

                    cursor1.execute(
                        'insert into staff.userw(username,password,name,sumname,reg_date,email) values (%s,%s,%s,%s,%s,%s)',
                        (

                            userentry.get(),
                            passwdentry.get(),
                            firstnameentry.get(),
                            lastnameentry.get(),
                            datetime.datetime.now(),
                            emailentry.get()))






                    statusstrevaluator = 'EVALUATOR'
                    cursor1.execute('insert into status(user,status) values(%s,%s)',
                                    (userentry.get(),
                                     statusstrevaluator))

                    cursor1.execute(
                        'insert into staff.evaluator(username,exp_years,FIM) values(%s,%s,%s)', (
                            userentry.get(),
                            expyearsentry.get(),
                            firmentry.get()

                        ))
                    tk.messagebox.showinfo("USER REGISTRATION", "USER ADDED SUCCESSFULLY", parent=employeeroot)
                except:
                    tk.messagebox.showerror("ERROR",
                                        "USER WASNT REGISTERED.PLEASE CHECK THAT  ALL REQUIRED FIELDS ARE FILLED!",
                                        parent=employeeroot)
                db.commit()
                db.close()

            def Reset():
                userentry.delete(0, END)
                passwdentry.delete(0, END)
                firstnameentry.delete(0, END)
                lastnameentry.delete(0, END)
                emailentry.delete(0, END)
                expyearsentry.delete(0, END)
                firmentry.delete(0, END)

            # ---------BUTTONS--------------

            addbutt = tk.Button(mainframe, text='ADD USER', fg='blue', font=('arial', 12, 'bold'),
                                command=Adduserevaluator)
            addbutt.place(relx=0.001, rely=0.8, relwidth=0.3, relheight=0.19)

            addbutt = tk.Button(mainframe, text='RESET', fg='blue', font=('arial', 12, 'bold'), command=Reset)
            addbutt.place(relx=0.32, rely=0.8, relwidth=0.3, relheight=0.19)

            def Back():
                employeeroot.destroy()

            addbutt = tk.Button(mainframe, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
            addbutt.place(relx=0.64, rely=0.8, relwidth=0.3, relheight=0.19)

        def newmanager():
            master.destroy()
            employeeroot = tk.Toplevel()
            employeeroot.title("MANAGER REGISTRATION")
            canvas = tk.Canvas(employeeroot, width=600, height=450)
            canvas.pack()
            mainframe = tk.Frame(employeeroot, bg='red')
            mainframe.place(relx=0, rely=0, relheight=1, relwidth=1)

            # --------------ENTRIES AND LABELS-------------------

            num = tk.Label(mainframe, text='Username', fg='red', font=('arial', 12, 'bold'), bd=7)
            num.grid(row=0, column=0, sticky='W', padx=5)
            userentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            userentry.grid(row=0, column=1, sticky='W', padx=5)

            nu2 = tk.Label(mainframe, text='Password', fg='red', font=('arial', 12, 'bold'), bd=7)
            nu2.grid(row=1, column=0, sticky='W', padx=5)
            passwdentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            passwdentry.grid(row=1, column=1, sticky='W', padx=5)

            num3 = tk.Label(mainframe, text='FirstName', fg='red', font=('arial', 12, 'bold'), bd=7)
            num3.grid(row=2, column=0, sticky='W', padx=5)
            firstnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            firstnameentry.grid(row=2, column=1, sticky='W', padx=5)

            num4 = tk.Label(mainframe, text='LastName', fg='red', font=('arial', 12, 'bold'), bd=7)
            num4.grid(row=3, column=0, sticky='W', padx=5)
            lastnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            lastnameentry.grid(row=3, column=1, sticky='W', padx=5)

            num6 = tk.Label(mainframe, text='Email', fg='red', font=('arial', 12, 'bold'), bd=7)
            num6.grid(row=4, column=0, sticky='W', padx=5)
            emailentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            emailentry.grid(row=4, column=1, sticky='W', padx=5)

            num7 = tk.Label(mainframe, text='Years of Experience', fg='red', font=('arial', 12, 'bold'), bd=7)
            num7.grid(row=5, column=0, sticky='W', padx=5)
            expyearsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            expyearsentry.grid(row=5, column=1, sticky='W', padx=5)

            num8 = tk.Label(mainframe, text='Firm', fg='red', font=('arial', 12, 'bold'), bd=7)
            num8.grid(row=6, column=0, sticky='W', padx=5)
            firmentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            firmentry.grid(row=6, column=1, sticky='W', padx=5)

            def Addusermanager():
                db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
                cursor1 = db.cursor()

                try:

                    cursor1.execute(
                        'insert into staff.userw(username,password,name,sumname,reg_date,email) values (%s,%s,%s,%s,%s,%s)',
                        (

                            userentry.get(),
                            passwdentry.get(),
                            firstnameentry.get(),
                            lastnameentry.get(),
                            datetime.datetime.now(),
                            emailentry.get()))






                    statusstrmanager = 'MANAGER'
                    cursor1.execute('insert into status(user,status) values(%s,%s)',
                                    (userentry.get(),
                                     statusstrmanager))

                    cursor1.execute(
                        'insert into staff.manager(managerUsername,exp_years,FIM) values(%s,%s,%s)', (
                            userentry.get(),
                            expyearsentry.get(),
                            firmentry.get()

                        ))
                    tk.messagebox.showinfo("USER REGISTRATION", "USER ADDED SUCCESSFULLY", parent=employeeroot)
                except:
                    tk.messagebox.showerror(
                    "ERROR", "USER WASNT REGISTERED.PLEASE CHECK THAT  ALL REQUIRED FIELDS ARE FILLED!",
                    parent=employeeroot)
                db.commit()
                db.close()


            def Reset():
                userentry.delete(0, END)
                passwdentry.delete(0, END)
                firstnameentry.delete(0, END)
                lastnameentry.delete(0, END)
                emailentry.delete(0, END)
                expyearsentry.delete(0, END)
                firmentry.delete(0, END)

            # ---------BUTTONS--------------

            addbutt = tk.Button(mainframe, text='ADD USER', fg='blue', font=('arial', 12, 'bold'),
                                command=Addusermanager)
            addbutt.place(relx=0.001, rely=0.8, relwidth=0.3, relheight=0.19)

            addbutt = tk.Button(mainframe, text='RESET', fg='blue', font=('arial', 12, 'bold'), command=Reset)
            addbutt.place(relx=0.32, rely=0.8, relwidth=0.3, relheight=0.19)

            def Back():
                employeeroot.destroy()

            addbutt = tk.Button(mainframe, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
            addbutt.place(relx=0.64, rely=0.8, relwidth=0.3, relheight=0.19)

        def newemployee():
            master.destroy()
            employeeroot = tk.Toplevel()
            employeeroot.title("EMPLOYEE REGISTRATION")
            canvas = tk.Canvas(employeeroot, width=600, height=450)
            canvas.pack()
            mainframe = tk.Frame(employeeroot, bg='red')
            mainframe.place(relx=0, rely=0, relheight=1, relwidth=1)

            # --------------ENTRIES AND LABELS-------------------

            num = tk.Label(mainframe, text='Username', fg='red', font=('arial', 12, 'bold'), bd=7)
            num.grid(row=0, column=0, sticky='W', padx=5)
            userentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            userentry.grid(row=0, column=1, sticky='W', padx=5)

            nu2 = tk.Label(mainframe, text='Password', fg='red', font=('arial', 12, 'bold'), bd=7)
            nu2.grid(row=1, column=0, sticky='W', padx=5)
            passwdentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            passwdentry.grid(row=1, column=1, sticky='W', padx=5)

            num3 = tk.Label(mainframe, text='FirstName', fg='red', font=('arial', 12, 'bold'), bd=7)
            num3.grid(row=2, column=0, sticky='W', padx=5)
            firstnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            firstnameentry.grid(row=2, column=1, sticky='W', padx=5)

            num4 = tk.Label(mainframe, text='LastName', fg='red', font=('arial', 12, 'bold'), bd=7)
            num4.grid(row=3, column=0, sticky='W', padx=5)
            lastnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            lastnameentry.grid(row=3, column=1, sticky='W', padx=5)

            num6 = tk.Label(mainframe, text='Email', fg='red', font=('arial', 12, 'bold'), bd=7)
            num6.grid(row=4, column=0, sticky='W', padx=5)
            emailentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            emailentry.grid(row=4, column=1, sticky='W', padx=5)

            num7 = tk.Label(mainframe, text='Bio', fg='red', font=('arial', 12, 'bold'), bd=7)
            num7.grid(row=5, column=0, sticky='W', padx=5)
            bioentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            bioentry.grid(row=5, column=1, sticky='W', padx=5)

            num8 = tk.Label(mainframe, text='Statistics', fg='red', font=('arial', 12, 'bold'), bd=7)
            num8.grid(row=6, column=0, sticky='W', padx=5)
            statisticsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            statisticsentry.grid(row=6, column=1, sticky='W', padx=5)

            num9 = tk.Label(mainframe, text='Certificates', fg='red', font=('arial', 12, 'bold'), bd=7)
            num9.grid(row=7, column=0, sticky='W', padx=5)
            certificatesentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            certificatesentry.grid(row=7, column=1, sticky='W', padx=5)

            num10 = tk.Label(mainframe, text='Awards', fg='red', font=('arial', 12, 'bold'), bd=7)
            num10.grid(row=8, column=0, sticky='W', padx=5)
            awardsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
            awardsentry.grid(row=8, column=1, sticky='W', padx=5)

            # ---------------ADD USER - RESET - BACK-----------------

            def Adduseremployee():
                db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
                cursor1 = db.cursor()

                try:

                    cursor1.execute(
                        'insert into staff.userw(username,password,name,sumname,reg_date,email) values (%s,%s,%s,%s,%s,%s)',
                        (

                            userentry.get(),
                            passwdentry.get(),
                            firstnameentry.get(),
                            lastnameentry.get(),
                            datetime.datetime.now(),
                            emailentry.get()))


                    statusstr = 'EMPLOYEE'
                    cursor1.execute('insert into status(user,status) values(%s,%s)',
                                    (userentry.get(),
                                     statusstr))

                    cursor1.execute(
                        'insert into staff.employee(username,bio,sustatikes,certificates,awards) values(%s,%s,%s,%s,%s)', (
                            userentry.get(),
                            bioentry.get(),
                            statisticsentry.get(),
                            certificatesentry.get(),
                            awardsentry.get())

                        )

                    tk.messagebox.showinfo("USER REGISTRATION", "USER ADDED SUCCESSFULLY", parent=employeeroot)

                except:
                    tk.messagebox.showerror("ERROR", "USER WASNT REGISTERED.PLEASE CHECK THAT  ALL REQUIRED FIELDS ARE FILLED!",parent=employeeroot)
                db.commit()
                db.close()


            def Reset():
                userentry.delete(0, END)
                passwdentry.delete(0, END)
                firstnameentry.delete(0, END)
                lastnameentry.delete(0, END)
                emailentry.delete(0, END)
                bioentry.delete(0, END)
                statisticsentry.delete(0, END)
                certificatesentry.delete(0, END)
                awardsentry.delete(0, END)

            # ---------BUTTONS--------------

            addbutt = tk.Button(mainframe, text='ADD USER', fg='blue', font=('arial', 12, 'bold'),
                                command=Adduseremployee)
            addbutt.place(relx=0.001, rely=0.8, relwidth=0.3, relheight=0.19)

            addbutt = tk.Button(mainframe, text='RESET', fg='blue', font=('arial', 12, 'bold'), command=Reset)
            addbutt.place(relx=0.32, rely=0.8, relwidth=0.3, relheight=0.19)

            def Back():
                employeeroot.destroy()

            addbutt = tk.Button(mainframe, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
            addbutt.place(relx=0.64, rely=0.8, relwidth=0.3, relheight=0.19)

            #employeeroot.mainloop()

        label1 = tk.Label(master, text="PLEASE SELECT ONLY ONE OF THE FOLLOWING:", font=('arial', 12, 'bold'), bd=7)
        label1.grid(row=0, column=0, )

        var1 = tk.IntVar()

        employeecheckbut = tk.Checkbutton(master, text="EMPLOYEE", variable=var1, onvalue=1, offvalue=0,
                                          font=('arial', 12, 'bold'), bd=7)
        employeecheckbut.grid(row=1, sticky=W)

        var2 = tk.IntVar()
        managercheckbut = tk.Checkbutton(master, text="MANAGER", variable=var2, onvalue=1, offvalue=0,
                                         font=('arial', 12, 'bold'), bd=7)
        managercheckbut.grid(row=2, sticky=W)
        var3 = tk.IntVar()
        evaluatorcheckbut = tk.Checkbutton(master, text="EVALUATOR", variable=var3, onvalue=1, offvalue=0,
                                           font=('arial', 12, 'bold'), bd=7)
        evaluatorcheckbut.grid(row=3, sticky=W)
        Button(master, text='Cancel', font=('arial', 12, 'bold'), command=master.destroy).grid(row=5, column=0,
                                                                                               sticky=W, pady=4)
        Button(master, text='Confirm', font=('arial', 12, 'bold'), command=click_me).grid(row=4, column=0, sticky=W,
                                                                                          pady=4)
        #master.mainloop()

    # ----------------------NEW COMPANY------------------------------------------------------------------------

    def newcompany():
        companyroot = tk.Toplevel()
        companyroot.title("COMPANY REGISTRATION")
        canvas = tk.Canvas(companyroot, width=600, height=450)
        canvas.pack()
        mainframe = tk.Frame(companyroot, bg='red')
        mainframe.place(relx=0, rely=0, relheight=1, relwidth=1)

        # --------------ENTRIES AND LABELS-------------------

        phoneint = tk.IntVar()
        numberint= tk.IntVar()

        num = tk.Label(mainframe, text='AFM', fg='red', font=('arial', 12, 'bold'), bd=7)
        num.grid(row=0, column=0, sticky='W', padx=5)
        afmentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        afmentry.grid(row=0, column=1, sticky='W', padx=5)

        nu2 = tk.Label(mainframe, text='DOY', fg='red', font=('arial', 12, 'bold'), bd=7)
        nu2.grid(row=1, column=0, sticky='W', padx=5)
        doyentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        doyentry.grid(row=1, column=1, sticky='W', padx=5)

        num3 = tk.Label(mainframe, text='Name', fg='red', font=('arial', 12, 'bold'), bd=7)
        num3.grid(row=2, column=0, sticky='W', padx=5)
        nameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        nameentry.grid(row=2, column=1, sticky='W', padx=5)

        num4 = tk.Label(mainframe, text='Phone', fg='red', font=('arial', 12, 'bold'), bd=7)
        num4.grid(row=3, column=0, sticky='W', padx=5)
        phoneentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        phoneentry.grid(row=3, column=1, sticky='W', padx=5)

        num6 = tk.Label(mainframe, text='Street', fg='red', font=('arial', 12, 'bold'), bd=7)
        num6.grid(row=4, column=0, sticky='W', padx=5)
        streetentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        streetentry.grid(row=4, column=1, sticky='W', padx=5)

        num7 = tk.Label(mainframe, text='Number', fg='red', font=('arial', 12, 'bold'), bd=7)
        num7.grid(row=5, column=0, sticky='W', padx=5)
        numberentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        numberentry.grid(row=5, column=1, sticky='W', padx=5)

        num8 = tk.Label(mainframe, text='City', fg='red', font=('arial', 12, 'bold'), bd=7)
        num8.grid(row=6, column=0, sticky='W', padx=5)
        cityentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        cityentry.grid(row=6, column=1, sticky='W', padx=5)

        num8 = tk.Label(mainframe, text='Country', fg='red', font=('arial', 12, 'bold'), bd=7)
        num8.grid(row=7, column=0, sticky='W', padx=5)
        countryentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        countryentry.grid(row=7, column=1, sticky='W', padx=5)

        afm = tk.Label(mainframe, text='Title', fg='red', font=('arial', 12, 'bold'), bd=7)
        afm.grid(row=8, column=0, sticky='W', padx=5)
        titleentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        titleentry.grid(row=8, column=1, sticky='W', padx=5)

        afm = tk.Label(mainframe, text='Description', fg='red', font=('arial', 12, 'bold'), bd=7)
        afm.grid(row=9, column=0, sticky='W', padx=5)
        descriptionentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        descriptionentry.grid(row=9, column=1, sticky='W', padx=5)

        '''afm = tk.Label(mainframe, text='Belongs To', fg='red', font=('arial', 12, 'bold'), bd=7)
        afm.grid(row=10, column=0, sticky='W', padx=5)
        belongstoentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
        belongstoentry.grid(row=10, column=1, sticky='W', padx=5)'''

        # ---------------ADD USER - RESET - BACK-----------------

        def Addcompany():
            db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
            cursor1 = db.cursor()






            if afmentry.get() == '' or doyentry.get() == '' or nameentry.get() == '' or phoneentry.get() == '' or streetentry.get() == '' or numberentry.get() == '' or cityentry.get() == '' or countryentry.get() == '' or titleentry.get()=='':
                tk.messagebox.showerror("COMPANY REGISTRATION ERROR", "PLEASE FILL ALL REQUIRED FIELDS!",
                                            parent=companyroot)
            try:

                int(phoneentry.get())
                int(numberentry.get())

                cursor1.execute(
                    'insert into staff.company(AFM,DOY,name,phone,street,num,city,country) values (%s,%s,%s,%s,%s,%s,%s,%s)',
                    (

                        afmentry.get(),
                        doyentry.get(),
                        nameentry.get(),
                        phoneentry.get(),
                        streetentry.get(),
                        numberentry.get(),
                        cityentry.get(),
                        countryentry.get()))

                cursor1.execute('insert into staff.antikeim(title, descr,belongs_to) values (%s,%s,%s)', (
                    titleentry.get(),
                    descriptionentry.get(),
                    titleentry.get()

                ))
                tk.messagebox.showinfo("COMPANY STATUS", "COMPANY ADDED SUCCESSFULLY!", parent=companyroot)
            except:

                tk.messagebox.showerror("INPUT ERROR","PLEASE NOTE THAT PHONE AND NUMBER ENTRY MUST ONLY CONTAIN  NUMBERS!",parent=companyroot)








            db.commit()
            db.close()

        def Reset():
            afmentry.delete(0, END)
            doyentry.delete(0, END)
            nameentry.delete(0, END)
            phoneentry.delete(0, END)
            streetentry.delete(0, END)
            numberentry.delete(0, END)
            cityentry.delete(0, END)
            countryentry.delete(0, END)
            titleentry.delete(0, END)
            descriptionentry.delete(0, END)


        # ---------BUTTONS--------------

        addbutt = tk.Button(mainframe, text='ADD COMPANY', fg='blue', font=('arial', 12, 'bold'), command=Addcompany)
        addbutt.place(relx=0.001, rely=0.8, relwidth=0.3, relheight=0.19)

        addbutt = tk.Button(mainframe, text='RESET', fg='blue', font=('arial', 12, 'bold'), command=Reset)
        addbutt.place(relx=0.32, rely=0.8, relwidth=0.3, relheight=0.19)

        def Back():
            companyroot.destroy()

        addbutt = tk.Button(mainframe, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
        addbutt.place(relx=0.64, rely=0.8, relwidth=0.3, relheight=0.19)

        #companyroot.mainloop()

    def Logout():
        Exit = tk.messagebox.askyesno('LOGOUT','DO YOU REALLY WANT TO LOGOUT?',parent=root)
        if Exit > 0:
            root.destroy()
            return


    userbut = tk.Button(frame, text='CREATE A NEW USER', fg='blue', font=('arial', 12, 'bold'), command=usercheckbox)
    userbut.place(relx=0.3, rely=0.1, relwidth=0.4, relheight=0.2)

    userbut = tk.Button(frame, text='CREATE A NEW COMPANY', fg='blue', font=('arial', 12, 'bold'), command=newcompany)
    userbut.place(relx=0.3, rely=0.46, relwidth=0.4, relheight=0.2)

    logoutbut = tk.Button(frame, text='LOGOUT', fg='blue', font=('arial', 12, 'bold'), command=Logout)
    logoutbut.place(relx=0.3, rely=0.79, relwidth=0.4, relheight=0.2)

    root.mainloop()


#adminmainpage()
# =================================EMPLOYEE================================







def employeepage():
    roothaha.destroy()
    root = tk.Tk()
    root.title("EMPLOYEE")
    canvas = tk.Canvas(root, bg='red', height=600, width=1067)
    canvas.pack()
    label = tk.Label(root, text='EMPLOYEE ACCOUNT', fg='red', font=100)
    label.place(relx=0.42, rely=0.1)

    comp_button = tk.Button(root, text='EMPLOYEE INFO', fg='red', command=employeeinfo)
    comp_button.place(relx=0.1, rely=0.35, relwidth=0.2, relheight=0.1)

    personal_button = tk.Button(root, text='APPLY FOR A PROMOTION', fg='red', command=Jobs)
    personal_button.place(relx=0.4, rely=0.35, relwidth=0.2, relheight=0.1)

    employee_button = tk.Button(root, text='JOB APPLICATIONS', fg='red', command=showjobappliances)
    employee_button.place(relx=0.7, rely=0.35, relwidth=0.2, relheight=0.1)

    def Logout():
        exit = tk.messagebox.askyesno("LOGOUT","DO YOU REALLY WANT TO LOGOUT?",parent=root)
        if exit > 0:
            root.destroy()
            return

    logoutbutton = tk.Button(root, text='LOGOUT', fg='red', command=Logout)
    logoutbutton.place(relx=0.4, rely=0.6, relwidth=0.2, relheight=0.1)

    # evaluation_button = tk.Button(root, text='REMOVE JOB APPLICATION', fg='red')
    # evaluation_button.place(relx=0.4, rely=0.6, relwidth=0.2, relheight=0.1)

    root.mainloop()


def employeeinfo():
    root = tk.Toplevel()
    root.title("EMPLOYEE INFO")

    canvas = tk.Canvas(root, bg='yellow', width=650, height=600)
    canvas.pack()

    mainframe = tk.Frame(root, bg='white')
    mainframe.place(relx=0, rely=0, relwidth=1, relheight=1)

    username = tk.Label(mainframe, text='USERNAME', fg='red', font=('arial', 12, 'bold'), bd=7)
    username.grid(row=0, column=0, sticky='W', padx=5)
    usernameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    usernameentry.grid(row=0, column=1, sticky='W', padx=5)

    passwd1 = tk.Label(mainframe, text='PASSWORD', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd1.grid(row=1, column=0, sticky='W', padx=5)
    passwdentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    passwdentry.grid(row=1, column=1, sticky='W', padx=5)

    newpasswd1 = tk.Label(mainframe, text='FIRSTNAME', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd1.grid(row=2, column=0, sticky='W', padx=5)
    firstnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    firstnameentry.grid(row=2, column=1, sticky='W', padx=5)

    email2 = tk.Label(mainframe, text='LASTNAME', fg='red', font=('arial', 12, 'bold'), bd=7)
    email2.grid(row=3, column=0, sticky='W', padx=5)
    lastnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    lastnameentry.grid(row=3, column=1, sticky='W', padx=5)

    passwd2 = tk.Label(mainframe, text='REGISTER  DATE', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd2.grid(row=4, column=0, sticky='W', padx=5)
    registerdateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    registerdateentry.grid(row=4, column=1, sticky='W', padx=5)

    newpasswd3 = tk.Label(mainframe, text='EMAIL', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd3.grid(row=5, column=0, sticky='W', padx=5)
    emailentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    emailentry.grid(row=5, column=1, sticky='W', padx=5)

    email4 = tk.Label(mainframe, text='BIO', fg='red', font=('arial', 12, 'bold'), bd=7)
    email4.grid(row=6, column=0, sticky='W', padx=5)
    bioentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    bioentry.grid(row=6, column=1, sticky='W', padx=5)

    passwd4 = tk.Label(mainframe, text='STATISTICS', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd4.grid(row=7, column=0, sticky='W', padx=5)
    statisticsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    statisticsentry.grid(row=7, column=1, sticky='W', padx=5)

    newpasswd4 = tk.Label(mainframe, text='CERTIFICATES', fg='red', font=('arial', 12, 'bold'), bd=7)
    newpasswd4.grid(row=8, column=0, sticky='W', padx=5)
    certificatesentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    certificatesentry.grid(row=8, column=1, sticky='W', padx=5)

    passwd5 = tk.Label(mainframe, text='AWARDS', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=9, column=0, sticky='W', padx=5)
    awardsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    awardsentry.grid(row=9, column=1, sticky='W', padx=5)

    def Back():
        root.destroy()

    buttonback = tk.Button(mainframe, text='BACK', fg='red', font=('arial', 12, 'bold'), command=Back)
    buttonback.place(relx=0, rely=0.81, relwidth=0.5, relheight=0.19)

    def Display():
        db = mysql.connector.connect(host='localhost', port=3306, user='root', password='123456',
                                     database='staff')

        cursor2 = db.cursor()
        strh='"'
        cursor2.execute('SELECT * FROM userw where username="' + USERNAME.get() + strh)  # -----PWS KANE TAUTOPOIHSH ME TO USERNAME EDW?????


        res2 = cursor2.fetchall()
        # ------------USERW INFO------------

        usernameentry.config(state = NORMAL)
        usernameentry.delete(0, END)
        usernameentry.insert(END, res2[0][0])
        usernameentry.config(state = DISABLED)

        passwdentry.delete(0, END)
        passwdentry.insert(END, res2[0][1])

        firstnameentry.config(state = NORMAL)
        firstnameentry.delete(0, END)
        firstnameentry.insert(END, res2[0][2])
        firstnameentry.config(state = DISABLED)

        lastnameentry.config(state = NORMAL)
        lastnameentry.delete(0, END)
        lastnameentry.insert(END, res2[0][3])
        lastnameentry.config(state = DISABLED)

        registerdateentry.config(state = NORMAL)
        registerdateentry.delete(0, END)
        registerdateentry.insert(END, res2[0][4])
        registerdateentry.config(state = DISABLED)

        emailentry.config(state = NORMAL)
        emailentry.delete(0, END)
        emailentry.insert(END, res2[0][5])
        emailentry.config(state = DISABLED)


        cursor1 = db.cursor()
        strh = '"'
        cursor1.execute('SELECT bio,sustatikes,certificates,awards FROM employee where username="'+USERNAME.get() + strh
                ) # -----PWS KANE TAUTOPOIHSH ME TO USERNAME EDW?????

        res1 = cursor1.fetchall()
        # ----------------EMPLOYEE INFO-------------
        #print(res1)
        bioentry.delete(0, END)
        bioentry.insert(END, res1[0])

        statisticsentry.config(state = NORMAL)
        statisticsentry.delete(0, END)
        statisticsentry.insert(END, res1[0][1])
        statisticsentry.config(state = DISABLED)

        certificatesentry.config(state = NORMAL)
        certificatesentry.delete(0, END)
        certificatesentry.insert(END, res1[0][2])
        certificatesentry.config(state = DISABLED)

        awardsentry.config(state = NORMAL)
        awardsentry.delete(0, END)
        awardsentry.insert(END, res1[0][3])
        awardsentry.config(state = DISABLED)



        db.commit()
        db.close()

    buttondisplay = tk.Button(mainframe, text='DISPLAY MY INFO', fg='red', font=('arial', 12, 'bold'), command=Display)
    buttondisplay.place(relx=0.55, rely=0.81, relwidth=0.4, relheight=0.19)

    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor1 = db.cursor()


        cursor1.execute('update staff.userw set password=%s where username=%s', (passwdentry.get(),USERNAME.get())





        )
        cursor1.execute('update staff.employee set bio=%s where username=%s', (bioentry.get(),USERNAME.get())

        )


        db.commit()
        db.close()
        tk.messagebox.showinfo('RECORD FORM ENTRY ', 'RECORD UPDATED SUCCESSFULLY!', parent=root)
    button = tk.Button(mainframe, text='UPDATE INFO', fg='red', font=('arial', 12, 'bold'), command=Update)
    button.place(relx=0, rely=0.6, relwidth=0.5, relheight=0.2)

    #root.mainloop()


def Jobs():
    jobsroot = tk.Toplevel()
    jobsroot.title("JOBS")
    canvas = tk.Canvas(jobsroot, bg='yellow', width=800, height=600)
    canvas.pack()
    mainframe = tk.Frame(jobsroot, bg='white')
    mainframe.place(relx=0, rely=0, relwidth=0.79, relheight=0.4)
    bottomframe = tk.Frame(jobsroot, bg='red')
    bottomframe.place(relx=0, rely=0.41, relwidth=1, relheight=0.59)
    rightframe = tk.Frame(jobsroot, bg='white')
    rightframe.place(relx=0.8, rely=0, relwidth=0.2, relheight=0.4)

    passwd5 = tk.Label(mainframe, text='JOB ID', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=0, column=0, sticky='W', padx=5)
    jobidentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    jobidentry.grid(row=0, column=1, sticky='W', padx=5)

    passwd5 = tk.Label(mainframe, text='POSITION', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=1, column=0, sticky='W', padx=5)
    positionentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    positionentry.grid(row=1, column=1, sticky='W', padx=5)

    passwd5 = tk.Label(mainframe, text='SALARY', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=2, column=0, sticky='W', padx=5)
    salaryentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    salaryentry.grid(row=2, column=1, sticky='W', padx=5)

    passwd5 = tk.Label(mainframe, text='STATUS', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=3, column=0, sticky='W', padx=5)
    statusentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    statusentry.grid(row=3, column=1, sticky='W', padx=5)

    # ON CLICK TREEVIEW EVENT-------------
    def onclickevent(ev):
        viewinfo = records.focus()
        data = records.item(viewinfo)

        row = data['values']
        print(row)

        jobidentry.delete(0, END)
        jobidentry.insert(END, row[0])
        positionentry.delete(0, END)
        positionentry.insert(END, row[1])
        salaryentry.delete(0, END)
        salaryentry.insert(END, row[2])
        statusentry.delete(0, END)
        statusentry.insert(END, row[3])

    # ----------TREEVIEW-----------------
    scrollbar = Scrollbar(bottomframe, orient=VERTICAL)
    records = ttk.Treeview(bottomframe, yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns'] = ('AFM', 'DOY', 'NAME', 'PHONE')

    records.column('AFM', width=60)
    records.column('DOY', width=60)
    records.column('NAME', width=60)
    records.column('PHONE', width=60)

    records['show'] = 'headings'

    records.heading('AFM', text='Job ID')
    records.heading('DOY', text='Position')
    records.heading('NAME', text='Salary')
    records.heading('PHONE', text='Status')

    records.pack(fill=BOTH, expand=1)
    records.bind('<ButtonRelease-1>', onclickevent)

    def Display():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor1 = db.cursor()
        cursor1.execute('select id,position,salary,status from staff.job  ')
        res = cursor1.fetchall()

        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                # print(x)

                records.insert('', END, values=x)
        db.commit()
        db.close()

    Display()

    def Apply():

        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor1 = db.cursor()
        cursor1.execute('insert into applies(username, job_id,job_applie,status) values (%s,%s,%s,%s)',(
            USERNAME.get(),
            jobidentry.get(),
            positionentry.get(),
            statusentry.get()

        ))

        db.commit()
        db.close()
        tk.messagebox.showinfo("APPLICATION STATUS","YOU HAVE SUCCESSFULLY APPLIED FOR THE JOB", parent=jobsroot)
    def Back():
        jobsroot.destroy()

    backbutton = tk.Button(rightframe, text='APPLY FOR JOB', fg='red', font=('arial', 12, 'bold'), command=Apply)
    backbutton.place(relx=0, rely=0.0, relwidth=1, relheight=0.49)

    backbutton = tk.Button(rightframe, text='BACK', fg='red', font=('arial', 12, 'bold'), command=Back)
    backbutton.place(relx=0, rely=0.51, relwidth=1, relheight=0.49)

    #jobsroot.mainloop()

def showjobappliances():
    jobsroot = tk.Toplevel()
    jobsroot.title("MY APPLIANCES")
    canvas = tk.Canvas(jobsroot, bg='yellow', width=800, height=600)
    canvas.pack()
    mainframe = tk.Frame(jobsroot, bg='white')
    mainframe.place(relx=0, rely=0, relwidth=0.79, relheight=0.4)
    bottomframe = tk.Frame(jobsroot, bg='red')
    bottomframe.place(relx=0, rely=0.41, relwidth=1, relheight=0.59)
    rightframe = tk.Frame(jobsroot, bg='white')
    rightframe.place(relx=0.8, rely=0, relwidth=0.2, relheight=0.4)

    passwd5 = tk.Label(mainframe, text='JOB ID', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=0, column=0, sticky='W', padx=5)
    jobidentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    jobidentry.grid(row=0, column=1, sticky='W', padx=5)

    passwd5 = tk.Label(mainframe, text='POSITION', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=1, column=0, sticky='W', padx=5)
    positionentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    positionentry.grid(row=1, column=1, sticky='W', padx=5)

    passwd5 = tk.Label(mainframe, text='SALARY', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=2, column=0, sticky='W', padx=5)
    salaryentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    salaryentry.grid(row=2, column=1, sticky='W', padx=5)

    passwd5 = tk.Label(mainframe, text='STATUS', fg='red', font=('arial', 12, 'bold'), bd=7)
    passwd5.grid(row=3, column=0, sticky='W', padx=5)
    statusentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    statusentry.grid(row=3, column=1, sticky='W', padx=5)

    # ON CLICK TREEVIEW EVENT-------------
    def onclickevent(ev):
        viewinfo = records.focus()
        data = records.item(viewinfo)

        row = data['values']


        jobidentry.delete(0, END)
        jobidentry.insert(END, row[0])
        positionentry.delete(0, END)
        positionentry.insert(END, row[1])
        salaryentry.delete(0, END)
        salaryentry.insert(END, row[2])
        statusentry.delete(0, END)
        statusentry.insert(END, row[3])

    # ----------TREEVIEW-----------------
    scrollbar = Scrollbar(bottomframe, orient=VERTICAL)
    records = ttk.Treeview(bottomframe, yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns'] = ('AFM', 'DOY', 'NAME', 'PHONE')

    records.column('AFM', width=60)
    records.column('DOY', width=60)
    records.column('NAME', width=60)
    records.column('PHONE', width=60)

    records['show'] = 'headings'

    records.heading('AFM', text='Job ID')
    records.heading('DOY', text='Position')
    records.heading('NAME', text='Salary')
    records.heading('PHONE', text='Status')

    records.pack(fill=BOTH, expand=1)
    records.bind('<ButtonRelease-1>', onclickevent)

    def Display():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor1 = db.cursor()
        strh='"'
        cursor1.execute('select job_id,job_applie,salary,applies.status from staff.applies inner join job on job.id=applies.job_id where username="' + USERNAME.get() + strh,(

        )
                        )
        res = cursor1.fetchall()

        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                # print(x)

                records.insert('', END, values=x)
        db.commit()
        db.close()

    Display()

    def Delete():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor1 = db.cursor()
        cursor1.execute('delete  from staff.applies   where job_id=  '+ jobidentry.get(),

        )
        db.commit()
        db.close()
        tk.messagebox.showinfo("APPLICATION DELETION","JOB APPLICATION DELETED SUCCESSFULLY", parent=jobsroot)

    def Back():
        jobsroot.destroy()

    deletebutt = tk.Button(rightframe, text='DELETE APPLIANCE', fg='red', font=('arial', 12, 'bold'), command=Delete)
    deletebutt.place(relx=0, rely=0, relwidth=1, relheight=0.5)

    backbutton = tk.Button(rightframe, text='BACK', fg='red', font=('arial', 12, 'bold'), command=Back)
    backbutton.place(relx=0, rely=0.51, relwidth=1, relheight=0.49)
#employeepage()



# ================================LOGINGUI=====================================

def Login():
    db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
    cursor = db.cursor()
    cursor.execute('select username,password,status from userw inner join status on userw.username=status.user',(

    ))
    res = cursor.fetchall()

    cursor.execute('select username from userw', (

    ))
    resusername = cursor.fetchall()
    cursor.execute('select password from userw', (

    ))


    respassword = cursor.fetchall()
    usernamelist=[]
    for x in resusername:
        for y in x:
            usernamelist.append(y)

    passwordlist = []
    for w in respassword:
        for k in w:
            passwordlist.append(k)

    #print(entry_passwd.get() in passwordlist)

    i=0


    while (i < len(res)):




        if entry_email.get()=='' and entry_passwd.get()=='':
            tk.messagebox.showerror(" ERROR", "PLEASE INSERT A USERNAME AND A VALID PASSWORD")
            break

        elif entry_email.get()=='' and entry_passwd.get():
            tk.messagebox.showerror("USERNAME ERROR","PLEASE INSERT A USERNAME")
            entry_email.delete(0, END)
            entry_passwd.delete(0, END)
            break
        elif entry_passwd.get()=='' and entry_email.get():
            tk.messagebox.showerror("PASSWORD ERROR", "PLEASE INSERT A PASSWORD")
            entry_email.delete(0, END)
            entry_passwd.delete(0, END)
            break



        elif res[i][0]==entry_email.get() and res[i][1]==entry_passwd.get() and res[i][2]=={'ADMIN'}:
            adminmainpage()


        elif res[i][0]==entry_email.get() and res[i][1]==entry_passwd.get() and res[i][2]=={'MANAGER'}:
            managerpage()


        elif res[i][0]==entry_email.get() and res[i][1]==entry_passwd.get() and res[i][2]=={'EMPLOYEE'}:
            employeepage()

        elif res[i][0]==entry_email.get() and res[i][1]==entry_passwd.get() and res[i][2]=={'EVALUATOR'}:
            evaluatorpage()

        elif entry_email.get() not in usernamelist or entry_passwd.get() not in passwordlist:
            tk.messagebox.showerror("LOGIN ERROR", "WRONG USERNAME OR PASSWORD")
            entry_email.delete(0, END)
            entry_passwd.delete(0, END)
            break



        i += 1

    db.commit()
    db.close()


button = tk.Button(roothaha, text='LOGIN', fg='red', command=Login, font=80, )
button.place(relx=0.5, rely=0.55, relheight=0.1, relwidth=0.2, anchor='n')

roothaha.mainloop()



