import tkinter as tk
from tkinter import *
from tkinter import ttk, messagebox
import mysql.connector
import datetime

def evaluatorpage():
    root = tk.Tk()
    root.title('EVALUATOR ACCOUNT')

    canvas = tk.Canvas(root, bg='red', height=600, width=1067)
    canvas.pack()
    label = tk.Label(root, text='EVALUATOR ACCOUNT', fg='red', font=100)
    label.place(relx=0.42, rely=0.1)

    comp_button = tk.Button(root, text='JOBS', fg='red', command=Jobs)
    comp_button.place(relx=0.1, rely=0.35, relwidth=0.2, relheight=0.1)

    personal_button = tk.Button(root, text='PERSONAL INFO', fg='red', command=Personalinfo )
    personal_button.place(relx=0.4, rely=0.35, relwidth=0.2, relheight=0.1)

    employee_button = tk.Button(root, text='INSERT A JOB', fg='red', command=InsertJob)
    employee_button.place(relx=0.7, rely=0.35, relwidth=0.2, relheight=0.1)

    evaluation_button = tk.Button(root, text='VIEW/EDIT MY JOBS', fg='red', command=MyJobs)
    evaluation_button.place(relx=0.4, rely=0.6, relwidth=0.2, relheight=0.1)

    def Exit():
        Exit = tk.messagebox.askyesno("LOGOUT",'DO YOU REALLY WANT TO LOGOUT?')
        if Exit > 0:
            root.destroy()
            return

    exitbutton = tk.Button(root,text='EXIT', fg='red', command=Exit)
    exitbutton.place(relx=0.7,rely=0.6, relwidth=0.2,relheight=0.1)

    root.mainloop()


def Personalinfo():

    personalroot = tk.Toplevel()
    personalroot.title('USER INFORMATION')
    canvas = tk.Canvas(personalroot, height=400, width=600, bg='red')
    canvas.pack()
    mainframe = tk.Frame(personalroot, bg='white')
    mainframe.place(relx=0, rely=0, relwidth=1, relheight=1)


    # ----------DISPLAY EVALUATORS INFO AUTOMATICALLY-----------------------

    def Display():
        db = mysql.connector.connect(host='localhost', port=3306, user='root', password='123456',
                                     database='staff')

        cursor1 = db.cursor()
        cursor1.execute('SELECT * FROM staff.userw where username like "%avougiouklo"')  # -----PWS KANE TAUTOPOIHSH ME TO USERNAME EDW?????


        res1 = cursor1.fetchall()
        for x in res1:

            usernameentry.insert(END, x[0])
            passwordentry.insert(END, x[1])
            firstnameentry.insert(END, x[2])
            lastnameentry.insert(END, x[3])
            regentry.insert(END, x[4])
            emailentry.insert(END, x[5])

        cursor1.execute('select exp_years,FIM from staff.evaluator where username like "%avougiouklo"')
        res2 = cursor1.fetchall()

        for y in res2:
            expyearsentry.insert(END, y[0])
            firmentry.insert(END, y[1])

        db.commit()
        db.close()

    # ------------------ ENTRIES AND LABELS---------------------------------------------------------

    afm = tk.Label(mainframe, text='Username', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=0, column=0, sticky='W', padx=5)
    usernameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    usernameentry.grid(row=0, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Password', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=1, column=0, sticky='W', padx=5)
    passwordentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    passwordentry.grid(row=1, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='FirstName', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=2, column=0, sticky='W', padx=5)
    firstnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    firstnameentry.grid(row=2, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='LastName', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=3, column=0, sticky='W', padx=5)
    lastnameentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    lastnameentry.grid(row=3, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Register Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=4, column=0, sticky='W', padx=5)
    regentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    regentry.grid(row=4, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Email', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=5, column=0, sticky='W', padx=5)
    emailentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    emailentry.grid(row=5, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Years of Experience', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=6, column=0, sticky='W', padx=5)
    expyearsentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    expyearsentry.grid(row=6, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Firm', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=7, column=0, sticky='W', padx=5)
    firmentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    firmentry.grid(row=7, column=1, sticky='W', padx=5)

    Display()

    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        cursor.execute('update staff.userw set password=%s,name=%s,sumname=%s,reg_date=%s,email=%s where username=%s',(


        passwordentry.get(),
        firstnameentry.get(),
        lastnameentry.get(),
        regentry.get(),
        emailentry.get(),
        usernameentry.get()
        ))

        cursor.execute('update staff.evaluator set exp_years=%s,FIM=%s where username=%s',(
        expyearsentry.get(),
        firmentry.get(),
        usernameentry.get()
        ))

        db.commit()
        db.close()
        tk.messagebox.showinfo('RECORD FORM ENTRY ', 'RECORD UPDATED SUCCESSFULLY!')

    # ------------BUTTONS FOR EVALUATORS INFO---------------------------------
    updatebutt = tk.Button(mainframe, text='UPDATE', fg='blue', font=('arial', 12, 'bold'), command=Update)
    updatebutt.place(relx=0.1, rely=0.75, relwidth=0.25, relheight=0.25)

    def Back():
        personalroot.destroy()




    backbutt = tk.Button(mainframe, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
    backbutt.place(relx=0.6, rely=0.75, relwidth=0.25, relheight=0.25)

    #personalroot.mainloop()

def Jobs():
    jobsroot = tk.Toplevel()
    jobsroot.title("JOBS")
    canvas = tk.Canvas(jobsroot, bg='white', width=800, height=600)
    canvas.pack()
    mainframe = tk.Frame(jobsroot, bg='red')
    mainframe.place(relx=0, rely=0, relwidth=0.8, relheight=0.55)
    bottomframe = tk.Frame(jobsroot, bg='yellow')
    bottomframe.place(relx=0, rely=0.57, relwidth=1, relheight=0.43)

    def Treeinfo(ev):
        viewinfo = records.focus()
        Datadisplay = records.item(viewinfo)
        row = Datadisplay['values']
        jobidentry.delete(0,END)
        jobidentry.insert(END,row[0])
        startdateentry.delete(0,END)
        startdateentry.insert(END,row[1])
        salaryentry.delete(0,END)
        salaryentry.insert(END,row[2])
        positionentry.delete(0,END)
        positionentry.insert(END,row[3])
        edraentry.delete(0,END)
        edraentry.insert(END,row[4])
        announcedateentry.delete(0, END)
        announcedateentry.insert(END, row[5])
        submissiondateentry.delete(0, END)
        submissiondateentry.insert(END, row[6])
        evaluatorentry.delete(0, END)
        evaluatorentry.insert(END, row[7])



    # ------------------CREATION OF TREEVIEW----------------------------------

    scrollbar = Scrollbar(bottomframe, orient=VERTICAL)
    records = ttk.Treeview(bottomframe, yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns'] = ('AFM', 'DOY', 'NAME', 'PHONE', 'STREET', 'NUM', 'CITY','kappa')

    records.column('AFM', width=60)
    records.column('DOY', width=60)
    records.column('NAME', width=60)
    records.column('PHONE', width=60)
    records.column('STREET', width=60)
    records.column('NUM', width=60)
    records.column('CITY', width=60)
    records.column('kappa', width=60)


    records['show'] = 'headings'

    records.heading('AFM', text='JOB ID')
    records.heading('DOY', text='START DATE')
    records.heading('NAME', text='SALARY')
    records.heading('PHONE', text='POSITION')
    records.heading('STREET', text='EDRA')
    records.heading('NUM', text='ANNOUNCE DATE')
    records.heading('CITY', text='SUBMISSION DATE')
    records.heading('kappa', text='EVALUATOR')

    records.pack(fill=BOTH, expand=1)
    records.bind('<ButtonRelease-1>', Treeinfo)

    # -------------------ENTRIES AND LABELS--------------------------------

    afm = tk.Label(mainframe, text='Job ID', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=0, column=0, sticky='W', padx=5)
    jobidentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    jobidentry.grid(row=0, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Start Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=1, column=0, sticky='W', padx=5)
    startdateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    startdateentry.grid(row=1, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Salary', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=2, column=0, sticky='W', padx=5)
    salaryentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    salaryentry.grid(row=2, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Position', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=3, column=0, sticky='W', padx=5)
    positionentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    positionentry.grid(row=3, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Edra', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=4, column=0, sticky='W', padx=5)
    edraentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    edraentry.grid(row=4, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Announce Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=5, column=0, sticky='W', padx=5)
    announcedateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    announcedateentry.grid(row=5, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Submission Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=6, column=0, sticky='W', padx=5)
    submissiondateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    submissiondateentry.grid(row=6, column=1, sticky='W', padx=5)
    afm = tk.Label(mainframe, text='Evaluator', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=7, column=0, sticky='W', padx=5)
    evaluatorentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    evaluatorentry.grid(row=7, column=1, sticky='W', padx=5)

    # -------------------DISPLAY-UPDATE--------------------------
    def Display():
        db = mysql.connector.connect(host='127.0.0.1', port='3306', user='root', password='123456', database='staff')
        cursor = db.cursor()
        cursor.execute(
            'SELECT id,start_date,salary,position,edra,announce_date,submission_date,evaluator FROM staff.job  ',

            )
        res = cursor.fetchall()


        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                records.insert('', END, values=x)

        db.commit()
        db.close()
    Display()
    # STO UPDATE PREPEI NA KANW AUTHENTICATION TOU EVALUATOR STO JOB ME TO USERNAME STO USERW
    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        cursor.execute('update staff.job set id=%s,start_date=%s,salary=%s,position=%s,edra=%s,announce_date=%s,submission_date=%s where evaluator=%s', (

            jobidentry.get(),
            startdateentry.get(),
            salaryentry.get(),
            positionentry.get(),
            edraentry.get(),
            announcedateentry.get(),
            submissiondateentry.get(),
            evaluatorentry.get()



        ))



        db.commit()
        db.close()
        tk.messagebox.showinfo('RECORD FORM ENTRY ', 'RECORD UPDATED SUCCESSFULLY!')

    updatebutt = tk.Button(jobsroot, text='UPDATE', fg='blue', font=('arial', 12, 'bold'), command=Update)
    updatebutt.place(relx=0.8, rely=0, relwidth=0.19, relheight=0.2)

    def Back():
        jobsroot.destroy()

    backbutt = tk.Button(jobsroot, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
    backbutt.place(relx=0.8, rely=0.21, relwidth=0.19, relheight=0.2)

def InsertJob():
    insertjobsroot = tk.Toplevel()
    insertjobsroot.title("JOBS")
    canvas = tk.Canvas(insertjobsroot, bg='white', width=800, height=600)
    canvas.pack()
    mainframe = tk.Frame(insertjobsroot, bg='red')
    mainframe.place(relx=0, rely=0, relwidth=1, relheight=1)

    afm = tk.Label(mainframe, text='Job ID', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=0, column=0, sticky='W', padx=5)
    jobidentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    jobidentry.grid(row=0, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Start Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=1, column=0, sticky='W', padx=5)
    startdateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    startdateentry.grid(row=1, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Salary', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=2, column=0, sticky='W', padx=5)
    salaryentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    salaryentry.grid(row=2, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Position', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=3, column=0, sticky='W', padx=5)
    positionentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    positionentry.grid(row=3, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Edra', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=4, column=0, sticky='W', padx=5)
    edraentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    edraentry.grid(row=4, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Evaluator', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=5, column=0, sticky='W', padx=5)
    evaluatorentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    evaluatorentry.grid(row=5, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Announce Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=6, column=0, sticky='W', padx=5)
    announcedateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    announcedateentry.grid(row=6, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Submission Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=7, column=0, sticky='W', padx=5)
    submissiondateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    submissiondateentry.grid(row=7, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Title', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=8, column=0, sticky='W', padx=5)
    titleentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    titleentry.grid(row=8, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Description', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=9, column=0, sticky='W', padx=5)
    descriptionentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    descriptionentry.grid(row=9, column=1, sticky='W', padx=5)

    '''afm = tk.Label(mainframe, text='Belongs To', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=10, column=0, sticky='W', padx=5)
    belongstoentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    belongstoentry.grid(row=10, column=1, sticky='W', padx=5)'''

    def Insert():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        #cursor1=db.cursor()





        cursor.execute('insert into staff.job(id,start_date,salary,position,edra,evaluator,announce_date,submission_date) values (%s,%s,%s,%s,%s,%s,%s,%s)  '




                       ,(
            jobidentry.get(),
            startdateentry.get(),
            salaryentry.get(),
            positionentry.get(),
            edraentry.get(),
            evaluatorentry.get(),
            announcedateentry.get(),
            datetime.datetime.now(),

        ))

        cursor.execute(

            'insert into staff.antikeim(title,descr,belong_to) values(%s,%s,%s)'
            , (
                titleentry.get(),
                descriptionentry.get(),
                titleentry.get()
            ))
        cursor.execute('insert into needs(job_id,antikeim_title) values(%s,%s)',(
            jobidentry.get(),
            titleentry.get()
        ))


        db.commit()
        db.close()

    def Back():
        insertjobsroot.destroy()

    def Reset():
        jobidentry.delete(0, END)
        startdateentry.delete(0, END)
        salaryentry.delete(0, END)
        positionentry.delete(0, END)
        edraentry.delete(0, END)
        evaluatorentry.delete(0, END)
        announcedateentry.delete(0, END)
        submissiondateentry.delete(0, END)
        titleentry.delete(0, END)
        descriptionentry.delete(0, END)


    insertjobbutt = tk.Button(mainframe, text='INSERT NEW JOB', fg='blue', font=('arial', 12, 'bold'), command=Insert)
    insertjobbutt.place(relx=0.05, rely=0.7, relwidth=0.25, relheight=0.2)

    insertjobbutt = tk.Button(mainframe, text='RESET', fg='blue', font=('arial', 12, 'bold'), command=Reset)
    insertjobbutt.place(relx=0.31, rely=0.7, relwidth=0.25, relheight=0.2)

    insertjobbutt = tk.Button(mainframe, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
    insertjobbutt.place(relx=0.58, rely=0.7, relwidth=0.25, relheight=0.2)

def MyJobs():
    jobsroot = tk.Toplevel()
    jobsroot.title("JOBS")
    canvas = tk.Canvas(jobsroot, bg='white', width=800, height=600)
    canvas.pack()
    mainframe = tk.Frame(jobsroot, bg='red')
    mainframe.place(relx=0, rely=0, relwidth=0.8, relheight=0.55)
    bottomframe = tk.Frame(jobsroot, bg='yellow')
    bottomframe.place(relx=0, rely=0.57, relwidth=1, relheight=0.43)

    def Treeinfo(ev):
        viewinfo = records.focus()
        Datadisplay = records.item(viewinfo)
        row = Datadisplay['values']
        jobidentry.delete(0, END)
        jobidentry.insert(END, row[0])
        startdateentry.delete(0, END)
        startdateentry.insert(END, row[1])
        salaryentry.delete(0, END)
        salaryentry.insert(END, row[2])
        positionentry.delete(0, END)
        positionentry.insert(END, row[3])
        edraentry.delete(0, END)
        edraentry.insert(END, row[4])
        announcedateentry.delete(0, END)
        announcedateentry.insert(END, row[5])
        submissiondateentry.delete(0, END)
        submissiondateentry.insert(END, row[6])

    # ------------------CREATION OF TREEVIEW----------------------------------

    scrollbar = Scrollbar(bottomframe, orient=VERTICAL)
    records = ttk.Treeview(bottomframe, yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    records['columns'] = ('AFM', 'DOY', 'NAME', 'PHONE', 'STREET', 'NUM', 'CITY')

    records.column('AFM', width=60)
    records.column('DOY', width=60)
    records.column('NAME', width=60)
    records.column('PHONE', width=60)
    records.column('STREET', width=60)
    records.column('NUM', width=60)
    records.column('CITY', width=60)

    records['show'] = 'headings'

    records.heading('AFM', text='JOB ID')
    records.heading('DOY', text='START DATE')
    records.heading('NAME', text='SALARY')
    records.heading('PHONE', text='POSITION')
    records.heading('STREET', text='EDRA')
    records.heading('NUM', text='ANNOUNCE DATE')
    records.heading('CITY', text='SUBMISSION DATE')

    records.pack(fill=BOTH, expand=1)
    records.bind('<ButtonRelease-1>', Treeinfo)

    # -------------------ENTRIES AND LABELS--------------------------------

    afm = tk.Label(mainframe, text='Job ID', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=0, column=0, sticky='W', padx=5)
    jobidentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    jobidentry.grid(row=0, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Start Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=1, column=0, sticky='W', padx=5)
    startdateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    startdateentry.grid(row=1, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Salary', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=2, column=0, sticky='W', padx=5)
    salaryentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    salaryentry.grid(row=2, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Position', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=3, column=0, sticky='W', padx=5)
    positionentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    positionentry.grid(row=3, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Edra', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=4, column=0, sticky='W', padx=5)
    edraentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    edraentry.grid(row=4, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Announce Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=5, column=0, sticky='W', padx=5)
    announcedateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    announcedateentry.grid(row=5, column=1, sticky='W', padx=5)

    afm = tk.Label(mainframe, text='Submission Date', fg='red', font=('arial', 12, 'bold'), bd=7)
    afm.grid(row=6, column=0, sticky='W', padx=5)
    submissiondateentry = tk.Entry(mainframe, width=44, font=('arial', 12, 'bold'), bd=5, justify='left')
    submissiondateentry.grid(row=6, column=1, sticky='W', padx=5)

    # -------------------DISPLAY-UPDATE--------------------------
    def Display():
        db = mysql.connector.connect(host='127.0.0.1', port='3306', user='root', password='123456', database='staff')
        cursor = db.cursor()
        cursor.execute(
            'SELECT id,start_date,salary,position,edra,announce_date,submission_date FROM staff.job where evaluator like "%avougiouklo" ',

        )
        res = cursor.fetchall()

        if (len(res) != 0):
            records.delete(*records.get_children())
            for x in res:
                records.insert('', END, values=x)

        db.commit()
        db.close()

    Display()

    # STO UPDATE PREPEI NA KANW AUTHENTICATION TOU EVALUATOR STO JOB ME TO USERNAME STO USERW
    def Update():
        db = mysql.connector.connect(host='localhost', user='root', password='123456', db='staff')
        cursor = db.cursor()
        cursor.execute(
            'update staff.job set start_date=%s,salary=%s,position=%s,edra=%s,announce_date=%s where id=%s and submission_date=%s',
            (


                startdateentry.get(),
                salaryentry.get(),
                positionentry.get(),
                edraentry.get(),
                announcedateentry.get(),
                jobidentry.get(),
                submissiondateentry.get()

            ))

        db.commit()
        db.close()
        tk.messagebox.showinfo('RECORD FORM ENTRY ', 'RECORD UPDATED SUCCESSFULLY!')

    updatebutt = tk.Button(jobsroot, text='UPDATE', fg='blue', font=('arial', 12, 'bold'), command=Update)
    updatebutt.place(relx=0.8, rely=0, relwidth=0.19, relheight=0.2)

    def Back():
        jobsroot.destroy()

    backbutt = tk.Button(jobsroot, text='BACK', fg='blue', font=('arial', 12, 'bold'), command=Back)
    backbutt.place(relx=0.8, rely=0.21, relwidth=0.19, relheight=0.2)

#evaluatorpage()